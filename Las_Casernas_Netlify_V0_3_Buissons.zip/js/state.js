// État du joueur, horloge et sauvegarde locale.
const SAVE_KEY = 'lascasernas.save.v1';
const START_TIME = 7 * 60; // 07:00

export function newState() {
  return {
    version: 1,
    day: 1,
    time: START_TIME,          // minutes depuis minuit
    money: 42,
    stoke: 5,
    legend: 0,
    map: 'parking',
    x: 3, y: 5, facing: 'down',
    inventory: ['van', 'planche'],
    quests: {},                // { battery: 'active' | ... } — voir data/quests.js
    relations: { nico: 0, jo: 0, ancien: 0, lina: 0 },
    flags: {},                 // drapeaux de progression libres
    daily: {},                 // drapeaux remis à zéro chaque jour { cafe: true, ... }
    stats: { surfSessions: 0, wavesRidden: 0, nightsVan: 0, nightsCamping: 0, gigs: 0, bushWins: 0, bushEncounters: 0 },
  };
}

export const pad = n => String(n).padStart(2, '0');
export const fmtTime = t => `${pad(Math.floor(t / 60) % 24)}:${pad(t % 60)}`;

/** Avance l'horloge. Passer minuit change de jour (sans dormir, on enchaîne). */
export function advanceClock(s, minutes) {
  s.time += minutes;
  while (s.time >= 1440) { s.time -= 1440; s.day += 1; s.daily = {}; }
}

/** Se réveiller « le lendemain » à 07:00. Après minuit, c'est le même jour calendaire. */
export function wakeUp(s) {
  if (s.time >= START_TIME) s.day += 1;
  s.time = START_TIME;
  s.daily = {};
}

/** Applique des gains/pertes et renvoie les deltas effectivement appliqués. */
export function applyDeltas(s, d) {
  const out = {};
  for (const k of ['money', 'stoke', 'legend']) {
    if (!d[k]) continue;
    const before = s[k];
    s[k] = Math.max(0, s[k] + d[k]);
    if (s[k] !== before) out[k] = s[k] - before;
  }
  return out;
}

export function save(s) {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(s)); } catch { /* stockage plein ou privé */ }
}

export function load() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (!data || data.version !== 1) return null;
    // Fusion avec l'état par défaut : les nouveaux champs ajoutés plus tard restent valides.
    const base = newState();
    return { ...base, ...data,
      relations: { ...base.relations, ...data.relations },
      stats: { ...base.stats, ...data.stats } };
  } catch { return null; }
}

export function clearSave() {
  try { localStorage.removeItem(SAVE_KEY); } catch { /* rien */ }
}
