// Audio procédural léger. Aucun fichier externe : jingles générés avec WebAudio.
let ctx = null;
let enabled = true;

function ac() {
  if (!enabled) return null;
  if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return ctx;
}

function tone(freq, dur=.08, type='square', gain=.035, delay=0) {
  const c = ac(); if (!c) return;
  const o = c.createOscillator(), g = c.createGain();
  o.type = type; o.frequency.value = freq;
  const t = c.currentTime + delay;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + .01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(c.destination); o.start(t); o.stop(t + dur + .03);
}

export const audio = {
  setEnabled(v) { enabled = !!v; },
  get enabled() { return enabled; },
  bushIntro() { [220,277,330,196].forEach((f,i)=>tone(f,.12,'square',.03,i*.08)); },
  hit() { tone(520,.06,'square',.03); tone(680,.08,'square',.025,.05); },
  miss() { tone(180,.12,'sawtooth',.028); tone(130,.14,'sawtooth',.02,.07); },
  win() { [330,440,554,660].forEach((f,i)=>tone(f,.12,'triangle',.035,i*.09)); },
  flee() { [440,330,220].forEach((f,i)=>tone(f,.08,'square',.025,i*.06)); },
};
