// Couche DOM : HUD, dialogues, toasts, fondu au noir, menu.
import { fmtTime } from '../state.js';

const $ = id => document.getElementById(id);
const wait = ms => new Promise(r => setTimeout(r, ms));

export const ui = {
  dialogActive: false,
  menuOpen: false,
  _dlg: null,

  init() {
    this.el = {
      day: $('hud-day'), time: $('hud-time'), money: $('hud-money'), stoke: $('hud-stoke'), legend: $('hud-legend'),
      place: $('hud-place'), surf: $('hud-surf'), quest: $('hud-quest'),
      toasts: $('toasts'), fade: $('fade'), fadeText: $('fade-text'),
      prompt: $('prompt'), act: $('btn-act'),
      dialog: $('dialog'), speaker: $('dlg-speaker'), text: $('dlg-text'), choices: $('dlg-choices'), next: $('dlg-next'),
      menu: $('menu'), menuBody: $('menu-body'),
    };
    this.prev = {};
    this.el.dialog.addEventListener('pointerdown', e => {
      if (e.target.closest('.btn')) return;
      e.preventDefault();
      this._advance();
    });
  },

  hud(s, mapName, cond, objective) {
    const vals = { day: s.day, time: fmtTime(s.time), money: s.money, stoke: s.stoke, legend: s.legend };
    for (const [k, v] of Object.entries(vals)) {
      const el = this.el[k];
      const str = String(v);
      if (el.textContent !== str) {
        el.textContent = str;
        if (this.prev[k] !== undefined && k !== 'time') {
          const cell = el.parentElement; cell.classList.remove('bump'); void cell.offsetWidth; cell.classList.add('bump');
        }
        this.prev[k] = str;
      }
    }
    this.el.place.textContent = mapName;
    if (cond) {
      this.el.surf.hidden = false;
      this.el.surf.className = `surf-badge ${cond.color}`;
      this.el.surf.textContent = `Surf : ${cond.label}`;
    } else this.el.surf.hidden = true;
    this.el.quest.hidden = !objective;
    if (objective) this.el.quest.textContent = `★ ${objective}`;
  },

  toast(text, kind = '') {
    const d = document.createElement('div');
    d.className = `toast ${kind}`;
    d.textContent = text;
    this.el.toasts.appendChild(d);
    setTimeout(() => d.remove(), 2500);
    while (this.el.toasts.children.length > 4) this.el.toasts.firstChild.remove();
  },

  prompt(label) {
    const p = this.el.prompt;
    if (label) { p.textContent = `INTERAGIR — ${label}`; p.classList.add('ready'); this.el.act.classList.add('ready'); }
    else { p.textContent = 'Explore…'; p.classList.remove('ready'); this.el.act.classList.remove('ready'); }
  },

  /** Affiche une réplique. Avec `choices`, résout l'index choisi ; sinon résout au tap. */
  say(speaker, text, choices = null) {
    return new Promise(resolve => {
      const el = this.el;
      this.dialogActive = true;
      el.dialog.hidden = false;
      el.speaker.textContent = speaker || '';
      el.text.textContent = '';
      el.choices.innerHTML = '';
      el.next.hidden = true;
      let i = 0;
      const dlg = { typing: true, choices, resolve, sel: 0, ready: false };
      this._dlg = dlg;
      const finish = () => {
        clearInterval(dlg.timer);
        dlg.typing = false;
        el.text.textContent = text;
        if (choices) this._showChoices(dlg);
        else { el.next.hidden = false; setTimeout(() => { dlg.ready = true; }, 120); }
      };
      dlg.finish = finish;
      dlg.timer = setInterval(() => {
        i += 2;
        el.text.textContent = text.slice(0, i);
        if (i >= text.length) finish();
      }, 22);
    });
  },

  _showChoices(dlg) {
    const el = this.el;
    dlg.buttons = dlg.choices.map((ch, idx) => {
      const c = typeof ch === 'string' ? { label: ch } : ch;
      const b = document.createElement('button');
      b.className = 'btn' + (idx === 0 ? ' btn-primary' : '');
      b.innerHTML = '';
      b.append(document.createTextNode(c.label));
      if (c.sub) { const s = document.createElement('small'); s.textContent = c.sub; b.append(s); }
      b.disabled = true;
      b.addEventListener('click', () => this._choose(idx));
      el.choices.appendChild(b);
      return { b, disabled: !!c.disabled };
    });
    // Petit délai : évite qu'un tap destiné au texte valide un choix par accident
    dlg.sel = Math.max(0, dlg.buttons.findIndex(x => !x.disabled));
    setTimeout(() => {
      dlg.buttons.forEach((x, i) => { x.b.disabled = x.disabled; x.b.classList.toggle('btn-primary', i === dlg.sel); });
      dlg.ready = true;
    }, 220);
  },

  _choose(idx) {
    const d = this._dlg;
    if (!d || !d.ready || d.buttons[idx]?.disabled) return;
    this._close(idx);
  },

  _advance() {
    const d = this._dlg;
    if (!d) return;
    if (d.typing) return d.finish();
    if (!d.choices && d.ready) this._close();
  },

  _close(val) {
    const d = this._dlg;
    this._dlg = null;
    this.dialogActive = false;
    this.el.dialog.hidden = true;
    d.resolve(val);
  },

  dialogKey(key) {
    const d = this._dlg;
    if (!d) return;
    if (key === ' ' || key === 'Enter' || key === 'e' || key === 'z') {
      if (d.typing || !d.choices) return this._advance();
      if (d.ready) return this._choose(d.sel);
    }
    if (d.choices && d.ready && (key === 'ArrowDown' || key === 'ArrowUp')) {
      const n = d.buttons.length;
      let s = d.sel;
      for (let k = 0; k < n; k++) {
        s = (s + (key === 'ArrowDown' ? 1 : -1) + n) % n;
        if (!d.buttons[s].disabled) break;
      }
      d.sel = s;
      d.buttons.forEach((x, i) => x.b.classList.toggle('btn-primary', i === s));
    }
    const num = parseInt(key, 10);
    if (d.choices && d.ready && num >= 1 && num <= d.buttons.length) this._choose(num - 1);
  },

  async fade(text, ms, mid) {
    this.el.fadeText.textContent = text || '';
    this.el.fade.classList.add('on');
    await wait(380);
    if (mid) await mid();
    await wait(ms || 300);
    this.el.fade.classList.remove('on');
    await wait(300);
  },

  openMenu(html) {
    this.menuOpen = true;
    this.el.menuBody.innerHTML = html;
    this.el.menu.hidden = false;
  },
  closeMenu() {
    this.menuOpen = false;
    this.el.menu.hidden = true;
  },
};
