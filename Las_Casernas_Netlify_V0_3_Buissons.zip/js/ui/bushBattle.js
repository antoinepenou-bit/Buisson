import { BUSH_ACTIONS } from '../data/bushes.js';
import { audio } from './audio.js';

const $ = id => document.getElementById(id);
const wait = ms => new Promise(r => setTimeout(r, ms));

export const bushBattle = {
  active: false,
  init() {
    this.el = {
      root: $('bush-battle'), title: $('bb-title'), attack: $('bb-attack'), text: $('bb-text'), hint: $('bb-hint'),
      player: $('bb-player'), enemy: $('bb-enemy'), actions: $('bb-actions'), flee: $('bb-flee'), scene: $('bb-scene'),
      progress: $('bb-progress')
    };
    this.ctx = this.el.scene.getContext('2d');
  },

  async run(enemy, opts={}) {
    this.active = true;
    this.enemy = enemy;
    this.el.root.hidden = false;
    this.el.title.textContent = enemy.name.toUpperCase();
    this.el.actions.innerHTML = '';
    audio.bushIntro();
    await this.cinematic(enemy);

    let calm = 3, insist = enemy.chief ? 4 : 3, turn = 0, revealed = !!opts.revealFirst;
    while (calm > 0 && insist > 0) {
      const atk = enemy.pattern[turn % enemy.pattern.length];
      this.el.attack.textContent = atk.attack;
      this.el.text.textContent = atk.line;
      this.el.hint.textContent = revealed ? `Instinct du Roi de la forêt : ${labelFor(atk.best)} semble être la bonne réponse.` : atk.hint;
      this.updateBars(calm, insist);
      this.draw(enemy, 'idle', performance.now()/1000);
      const choice = await this.choose();
      if (choice === 'flee') {
        audio.flee();
        const chance = opts.fleeBonus ? .88 : .7;
        const ok = Math.random() < chance;
        this.el.text.textContent = ok ? 'Tu profites d’un flottement et disparais entre les pins.' : 'Tu tentes de filer, mais il te suit sur trois mètres en continuant sa phrase.';
        this.el.hint.textContent = ok ? 'FUITE RÉUSSIE' : 'FUITE RATÉE · -1 Stoke';
        this.draw(enemy, ok ? 'flee' : 'miss', performance.now()/1000);
        await wait(850);
        this.el.root.hidden = true; this.active = false;
        return { result:'flee', success:ok, stoke: ok ? 0 : -1, minutes: ok ? 10 : 15 };
      }
      if (choice === atk.best) {
        insist--; audio.hit();
        this.el.hint.textContent = 'BIEN JOUÉ · son Insistance baisse.';
        this.draw(enemy, 'hit', performance.now()/1000);
      } else {
        calm--; audio.miss();
        this.el.hint.textContent = `MAUVAIS COMBO · ${labelFor(atk.best)} aurait mieux marché.`;
        this.draw(enemy, 'miss', performance.now()/1000);
      }
      this.updateBars(calm, insist);
      await wait(700);
      turn++; revealed = false;
    }

    const win = insist <= 0;
    if (win) audio.win(); else audio.miss();
    this.el.attack.textContent = win ? 'PASSAGE LIBÉRÉ !' : 'SANG-FROID ÉPUISÉ';
    this.el.text.textContent = win ? `${enemy.name} s’écarte avec un respect inexplicable.` : 'Tu abandonnes le duel et fais un détour vexant dans les fougères.';
    this.el.hint.textContent = win ? '+ progression Roi de la forêt' : '-1 Stoke';
    this.draw(enemy, win ? 'win' : 'lose', performance.now()/1000);
    await wait(900);
    this.el.root.hidden = true; this.active = false;
    return { result: win ? 'win' : 'lose', success:win, stoke: win ? 1 : -1, legend: win && enemy.chief ? 2 : win ? 1 : 0, minutes: win ? 15 : 20 };
  },

  choose() {
    this.el.actions.innerHTML = '';
    return new Promise(resolve => {
      for (const a of BUSH_ACTIONS) {
        const b = document.createElement('button');
        b.className = 'bb-action'; b.innerHTML = `${a.label}<small>${a.sub}</small>`;
        b.onclick = () => resolve(a.id); this.el.actions.appendChild(b);
      }
      this.el.flee.onclick = () => resolve('flee');
    });
  },

  updateBars(calm, insist) {
    this.el.player.textContent = `SANG-FROID ${'●'.repeat(calm)}${'○'.repeat(3-calm)}`;
    const max = this.enemy?.chief ? 4 : 3;
    this.el.enemy.textContent = `INSISTANCE ${'●'.repeat(insist)}${'○'.repeat(max-insist)}`;
  },

  async cinematic(enemy) {
    this.el.attack.textContent = 'RENCONTRE DANS LES BUISSONS';
    this.el.text.textContent = enemy.intro;
    this.el.hint.textContent = `UN ${enemy.name.toUpperCase()} APPARAÎT !`;
    this.draw(enemy, 'intro', 0);
    this.updateBars(3, enemy.chief ? 4 : 3);
    await wait(900);
  },

  draw(enemy, state, t) {
    const c=this.ctx; c.imageSmoothingEnabled=false;
    c.fillStyle='#263b2c'; c.fillRect(0,0,240,120);
    // pins / buissons
    c.fillStyle='#3e6447'; for(let i=0;i<8;i++){ const x=i*34-10; c.fillRect(x,55+(i%2)*7,34,65); }
    c.fillStyle='#6f8a55'; for(let i=0;i<16;i++){ const x=(i*29)%250, y=78+(i%3)*9; c.fillRect(x,y,18,12); }
    c.fillStyle='#d4bd83'; c.fillRect(0,96,240,24);
    // joueur à gauche
    drawHuman(c,52,70,'#2b77a8','#6b3e1f',false,state==='lose');
    // ennemi
    if(enemy.duo){ drawHuman(c,167,66,enemy.color,'#5b351f',false,state==='hit'); drawHuman(c,197,69,'#e88770','#8b5a36',true,state==='hit'); }
    else drawBushEnemy(c,182,68,enemy,state);
    if(state==='intro'){ c.fillStyle='#fff7dc'; c.font='10px monospace'; c.textAlign='center'; c.fillText('!!',182,28); }
    if(state==='hit'){ c.fillStyle='#f7e29b'; c.font='18px monospace'; c.fillText('★',183,26); }
    if(state==='miss'){ c.fillStyle='#f29a84'; c.font='18px monospace'; c.fillText('!',52,28); }
  }
};

function labelFor(id){ return BUSH_ACTIONS.find(a=>a.id===id)?.label || id; }
function R(c,col,x,y,w,h){c.fillStyle=col;c.fillRect(Math.round(x),Math.round(y),w,h)}
function drawHuman(c,x,y,shirt,hair,bikini=false,dizzy=false){
  R(c,'#d99b70',x-5,y-26,10,10); R(c,hair,x-5,y-28,10,4);
  if(bikini){R(c,'#e25f77',x-6,y-15,12,4);R(c,'#d99b70',x-6,y-11,12,7);R(c,'#e25f77',x-5,y-4,10,5)}
  else R(c,shirt,x-7,y-15,14,16);
  R(c,'#d99b70',x-11,y-13,4,13);R(c,'#d99b70',x+7,y-13,4,13);
  R(c,'#33414c',x-6,y+1,5,15);R(c,'#33414c',x+1,y+1,5,15);
  if(dizzy){R(c,'#fff',x-3,y-22,2,2);R(c,'#fff',x+2,y-22,2,2)}
}
function drawBushEnemy(c,x,y,e,state){
  drawHuman(c,x,y,e.color,e.chief?'#6d5b45':'#6b3e1f',false,state==='hit');
  if(e.id==='parasol'){R(c,'#8f6237',x+10,y-42,2,35);c.fillStyle=e.accent;c.beginPath();c.arc(x+11,y-42,18,Math.PI,0);c.fill()}
  if(e.id==='bluecap'){R(c,e.accent,x-7,y-31,14,4);R(c,e.accent,x+2,y-29,9,2)}
  if(e.chief){R(c,'#6d5b45',x-4,y-18,8,16);R(c,'#1a1a1a',x-6,y-23,5,3);R(c,'#1a1a1a',x+1,y-23,5,3)}
}
