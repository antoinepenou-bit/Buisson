// Mini-jeu de timing générique : une jauge, une zone verte, un curseur qui va et vient.
// Utilisé par le surf (1 manche) et la scène ouverte (3 manches). Pour un nouveau mini-jeu :
// réutiliser run() avec un autre `theme` et ajouter son décor dans SCENES.
const $ = id => document.getElementById(id);
const wait = ms => new Promise(r => setTimeout(r, ms));

export const minigame = {
  active: false,
  _press: null,

  init() {
    this.el = { root: $('minigame'), kicker: $('mg-kicker'), title: $('mg-title'), gauge: $('mg-gauge'), zone: $('mg-zone'), cursor: $('mg-cursor'), info: $('mg-info'), btn: $('mg-btn'), scene: $('mg-scene') };
    this.sctx = this.el.scene.getContext('2d');
    this.el.btn.addEventListener('pointerdown', e => { e.preventDefault(); this.press(); });
  },

  press() {
    if (this.el.btn.disabled || !this._press) return;
    const f = this._press; this._press = null; f();
  },

  key(k) { if (k === ' ' || k === 'Enter' || k === 'e' || k === 'z') this.press(); },

  waitPress() { return new Promise(r => { this._press = r; }); },

  async run(o) {
    const el = this.el;
    this.active = true;
    el.root.hidden = false;
    el.kicker.textContent = o.kicker || '';
    el.title.textContent = o.title || '';
    el.info.textContent = o.hint || '';
    el.btn.textContent = o.button || 'GO';
    el.gauge.className = 'mg-gauge';
    this.scene = { theme: o.theme, state: 'wait', t0: performance.now(), hits: 0, notes: [] };
    let alive = true;
    const loop = now => {
      if (!alive) return;
      this.drawScene(now / 1000);
      if (this.cursorAnim) this.cursorAnim(now);
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);

    let hits = 0;
    for (let r = 0; r < (o.rounds || 1); r++) {
      const zone = o.zone;
      const zs = 0.06 + Math.random() * (0.88 - zone);
      el.zone.style.left = `${zs * 100}%`;
      el.zone.style.width = `${zone * 100}%`;
      el.gauge.className = 'mg-gauge';
      const sweep = Array.isArray(o.sweep) ? o.sweep[r] : (o.sweep || 1);
      const start = performance.now();
      let pos = 0;
      this.cursorAnim = now => {
        const k = ((now - start) / 1000) / sweep;
        const m = k % 2;
        pos = m < 1 ? m : 2 - m;
        el.cursor.style.left = `${pos * 100}%`;
      };
      if (o.rounds > 1) el.info.textContent = `Accord ${r + 1} / ${o.rounds} — ${o.hint || ''}`;
      el.btn.disabled = true;
      setTimeout(() => { el.btn.disabled = false; }, 250);
      this.scene.state = 'wait';
      await this.waitPress();
      this.cursorAnim = null;
      const hit = pos >= zs && pos <= zs + zone;
      if (hit) hits++;
      this.scene.hits = hits;
      this.scene.state = hit ? 'hit' : 'miss';
      this.scene.tHit = performance.now() / 1000;
      el.gauge.className = `mg-gauge ${hit ? 'hit' : 'miss'}`;
      el.info.textContent = hit ? (o.theme === 'surf' ? 'TAKE-OFF PARFAIT !' : 'Accord parfait !') : (o.theme === 'surf' ? 'Trop tard… la vague te passe dessus !' : 'Couac !');
      el.btn.disabled = true;
      await wait(o.rounds > 1 ? 750 : 900);
    }
    const success = hits >= (o.need || 1);
    this.scene.state = success ? 'win' : 'lose';
    this.scene.tHit = performance.now() / 1000;
    el.info.textContent = success
      ? (o.theme === 'surf' ? 'Tu ressors de l’eau avec le sourire.' : `${hits}/${o.rounds} — Le public est debout !`)
      : (o.theme === 'surf' ? 'Gros bouillon. Tu bois la tasse.' : `${hits}/${o.rounds} — Applaudissements polis…`);
    el.btn.textContent = 'CONTINUER';
    await wait(250);
    el.btn.disabled = false;
    await this.waitPress();
    alive = false;
    el.root.hidden = true;
    this.active = false;
    return { hits, success };
  },

  drawScene(t) {
    const c = this.sctx, s = this.scene;
    (s.theme === 'gig' ? drawGig : drawSurf)(c, s, t);
  },
};

const R = (c, col, x, y, w, h) => { c.fillStyle = col; c.fillRect(Math.round(x), Math.round(y), w, h); };

function drawSurf(c, s, t) {
  // Ciel, soleil, océan
  R(c, '#f3c98a', 0, 0, 240, 20); R(c, '#f3b16b', 0, 20, 240, 15); R(c, '#e8743b', 0, 35, 240, 10);
  R(c, '#fbe3a8', 180, 14, 18, 18); R(c, '#fbe3a8', 176, 18, 26, 10);
  R(c, '#1d5f8a', 0, 45, 240, 75);
  for (let i = 0; i < 12; i++) R(c, '#2b77a8', (i * 37 + t * 20) % 260 - 20, 60 + (i * 13) % 50, 14, 1);
  // La vague (lèvre qui déferle)
  const wx = 150 + Math.sin(t * 0.8) * 4;
  c.fillStyle = '#2b77a8';
  c.beginPath(); c.moveTo(0, 95); c.quadraticCurveTo(wx - 40, 92, wx, 55); c.quadraticCurveTo(wx + 22, 40, wx + 40, 52);
  c.quadraticCurveTo(wx + 30, 58, wx + 26, 70); c.lineTo(240, 95); c.lineTo(240, 120); c.lineTo(0, 120); c.fill();
  c.fillStyle = '#3d8fbf';
  c.beginPath(); c.moveTo(20, 100); c.quadraticCurveTo(wx - 30, 96, wx - 4, 64); c.lineTo(wx + 6, 70); c.quadraticCurveTo(wx - 20, 100, 20, 108); c.fill();
  for (let i = 0; i < 14; i++) {
    const a = i / 14;
    R(c, '#f4f8f6', wx + 18 + Math.cos(a * 3 + t * 4) * 10 + a * 20, 50 + Math.sin(a * 5 + t * 6) * 4 + a * 20, 3, 3);
  }
  R(c, '#f4f8f6', wx + 30, 70, 50, 3); R(c, '#9fd0ea', wx + 26, 74, 60, 2);
  const dt = t - (s.tHit || t);
  if (s.state === 'wait') {
    const by = Math.sin(t * 3) * 1.5;
    R(c, '#f4f1ea', 92, 84 + by, 30, 4); R(c, '#e8743b', 92, 85 + by, 30, 1);
    R(c, '#1f2a33', 100, 80 + by, 14, 4); R(c, '#e8b48a', 114, 79 + by, 5, 5); R(c, '#6b3e1f', 114, 78 + by, 5, 2);
    const arm = Math.sin(t * 8) > 0;
    R(c, '#e8b48a', arm ? 108 : 104, 86 + by, 2, 4);
  } else if (s.state === 'hit' || s.state === 'win') {
    const x = 120 - Math.min(60, dt * 50) + Math.sin(t * 2) * 6, y = 70 + Math.sin(t * 3) * 4;
    R(c, '#f4f8f6', x + 22, y + 10, 16, 3);
    R(c, '#f4f1ea', x - 4, y + 12, 30, 4); R(c, '#e8743b', x - 4, y + 13, 30, 1);
    R(c, '#e8743b', x + 8, y + 5, 4, 7); R(c, '#e8743b', x + 13, y + 5, 4, 7);
    R(c, '#2b77a8', x + 7, y - 6, 10, 11);
    R(c, '#e8b48a', x + 1, y - 5, 6, 2); R(c, '#e8b48a', x + 17, y - 7, 6, 2);
    R(c, '#e8b48a', x + 8, y - 13, 7, 7); R(c, '#6b3e1f', x + 8, y - 14, 7, 3); R(c, '#f3d36b', x + 8, y - 12, 7, 1);
    if (s.state === 'win') { c.fillStyle = '#2a1d14'; c.font = '14px "Bowlby One", sans-serif'; c.textAlign = 'center'; c.fillText('STOKÉ !', 70, 30); }
  } else {
    for (let i = 0; i < 18; i++) {
      const a = (i / 18) * Math.PI * 2;
      R(c, '#f4f8f6', 110 + Math.cos(a) * (10 + dt * 30), 80 + Math.sin(a) * (6 + dt * 14) - dt * 10, 3, 3);
    }
    const bx = 110 + dt * 25, by = 60 - dt * 30 + dt * dt * 40;
    R(c, '#f4f1ea', bx, by, 4, 26); R(c, '#e8743b', bx + 1, by, 1, 26);
    if (s.state === 'lose') { c.fillStyle = '#2a1d14'; c.font = '14px "Bowlby One", sans-serif'; c.textAlign = 'center'; c.fillText('GLOUPS', 60, 30); }
  }
}

function drawGig(c, s, t) {
  R(c, '#1a1410', 0, 0, 240, 120);
  // Cône de lumière
  c.fillStyle = 'rgba(243,211,107,.18)';
  c.beginPath(); c.moveTo(110, 0); c.lineTo(130, 0); c.lineTo(165, 92); c.lineTo(75, 92); c.fill();
  for (let i = 0; i < 15; i++) {
    const on = (Math.floor(t * 3) + i) % 3 !== 0;
    R(c, on ? ['#f3d36b', '#e8743b', '#7fd18b', '#9fd0ea'][i % 4] : '#4a3a2a', 8 + i * 16, 6 + Math.sin(i) * 2, 3, 3);
  }
  R(c, '#5a3a1e', 0, 88, 240, 8); R(c, '#8a5a2f', 0, 88, 240, 2);
  // Musicien (le joueur) avec guitare
  const jump = (s.state === 'hit' || s.state === 'win') ? Math.abs(Math.sin(t * 8)) * 3 : 0;
  const x = 112, y = 52 - jump;
  R(c, '#e8743b', x + 2, y + 24, 4, 12); R(c, '#e8743b', x + 10, y + 24, 4, 12);
  R(c, '#2b77a8', x, y + 10, 16, 15);
  R(c, '#e8b48a', x + 3, y - 2, 10, 12); R(c, '#6b3e1f', x + 3, y - 4, 10, 4); R(c, '#f3d36b', x + 3, y - 1, 10, 1);
  R(c, '#2a1d14', x + 5, y + 3, 2, 2); R(c, '#2a1d14', x + 10, y + 3, 2, 2);
  R(c, s.state === 'miss' || s.state === 'lose' ? '#2a1d14' : '#b0664a', x + 6, y + 7, s.state === 'miss' ? 3 : 5, s.state === 'miss' ? 3 : 1);
  R(c, '#c47a2f', x - 4, y + 16, 14, 10); R(c, '#e8a04b', x - 3, y + 17, 12, 8); R(c, '#2a1d14', x + 1, y + 19, 4, 4);
  R(c, '#6e4524', x + 10, y + 18, 18, 3); R(c, '#2a1d14', x + 27, y + 16, 4, 6);
  // Public
  const cheer = s.state === 'hit' || s.state === 'win';
  const skins = ['#e8b48a', '#c98d5e', '#f0c49b', '#a8643a', '#e0a77c'];
  const hairs = ['#2a1d14', '#d9b45a', '#8a2f1f', '#9a9590', '#2a1d14'];
  for (let i = 0; i < 11; i++) {
    const hx = 6 + i * 22, hop = cheer ? Math.abs(Math.sin(t * 7 + i)) * 5 : Math.sin(t * 1.5 + i) * 1;
    R(c, '#3b4a6b', hx - 2, 108 - hop, 16, 14);
    R(c, skins[i % 5], hx, 98 - hop, 12, 11); R(c, hairs[i % 5], hx, 96 - hop, 12, 4);
    if (cheer) { R(c, skins[i % 5], hx - 3, 92 - hop, 2, 8); R(c, skins[i % 5], hx + 13, 92 - hop, 2, 8); }
  }
  c.font = '12px "Bowlby One", sans-serif'; c.textAlign = 'center';
  if (cheer) {
    c.fillStyle = '#f3d36b';
    for (let i = 0; i < 4; i++) c.fillText('♪', 60 + i * 40 + Math.sin(t * 3 + i) * 6, 40 - ((t * 20 + i * 15) % 30));
  }
  if (s.state === 'miss' || s.state === 'lose') { c.fillStyle = '#f2a08a'; c.fillText(s.state === 'lose' ? 'BOF…' : 'COUAC !', 180, 40); }
  if (s.state === 'win') { c.fillStyle = '#7fd18b'; c.fillText('BRAVO !', 60, 40); }
}
