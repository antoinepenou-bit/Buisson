// Point d'entrée : écran titre, Continuer / Nouvelle partie, branchement des entrées et du menu.
import { newState, load, save, clearSave, fmtTime } from './state.js';
import { Game } from './engine/game.js';
import { initInput } from './engine/input.js';
import { ui } from './ui/ui.js';
import { minigame } from './ui/minigame.js';
import { bushBattle } from './ui/bushBattle.js';
import { audio } from './ui/audio.js';

const $ = id => document.getElementById(id);
const titleEl = $('title'), gameEl = $('game');

ui.init();
minigame.init();
bushBattle.init();

let game = null;
const input = initInput({
  onAction: () => game?.interact(),
  onMenu: () => toggleMenu(),
  route: () => {
    if (gameEl.hidden) return null;
    if (ui.dialogActive) return { key: k => ui.dialogKey(k) };
    if (minigame.active) return minigame;
    if (bushBattle.active) return null;
    if (ui.menuOpen) return { key: k => { if (k === 'Escape' || k === 'm') toggleMenu(false); } };
    if (game?.busy) return null;
    return 'world';
  },
});
game = new Game($('canvas'), input);

let soundOn = localStorage.getItem('lascasernas.sound') !== 'off';
audio.setEnabled(soundOn);
function refreshSoundButton() { $('btn-sound').textContent = `Son : ${soundOn ? 'ON' : 'OFF'}`; }
$('btn-sound').addEventListener('click', () => {
  soundOn = !soundOn;
  audio.setEnabled(soundOn);
  localStorage.setItem('lascasernas.sound', soundOn ? 'on' : 'off');
  refreshSoundButton();
});
refreshSoundButton();

function refreshTitle() {
  const s = load();
  $('btn-continue').hidden = !s;
  if (s) $('continue-info').textContent = `Jour ${s.day} · ${fmtTime(s.time)} · ${s.money} € · ★ ${s.legend}`;
}

function show(screen) {
  titleEl.hidden = screen !== 'title';
  gameEl.hidden = screen !== 'game';
}

function startGame(state, isNew) {
  show('game');
  game.start(state, isNew);
}

$('btn-continue').addEventListener('click', () => {
  const s = load();
  if (s) startGame(s, false);
});

$('btn-new').addEventListener('click', () => {
  if (load() && !confirm('Commencer une nouvelle partie ? La sauvegarde actuelle sera effacée.')) return;
  clearSave();
  startGame(newState(), true);
});

function toggleMenu(force) {
  const open = force ?? !ui.menuOpen;
  if (open) {
    if (!game || game.busy || ui.dialogActive) return;
    ui.openMenu(game.menuHtml());
  } else ui.closeMenu();
}

$('menu').addEventListener('click', e => {
  const b = e.target.closest('[data-menu]');
  if (!b) { if (e.target === $('menu')) toggleMenu(false); return; }
  const a = b.dataset.menu;
  toggleMenu(false);
  if (a === 'wait') {
    game.run(async () => {
      game.api.time(30);
      await game.api.say('', 'Tu t’assois sur le pare-chocs et tu regardes passer les nuages. Un goéland te juge.');
    });
  } else if (a === 'title') {
    save(game.s);
    game.stop();
    refreshTitle();
    show('title');
  }
});

// Sauvegarde à la fermeture / mise en arrière-plan
document.addEventListener('visibilitychange', () => { if (document.hidden && game?.s && !gameEl.hidden) save(game.s); });

refreshTitle();
show('title');
document.fonts?.load('8px Silkscreen');
