// Entrées : croix directionnelle tactile (glisser le doigt fonctionne), bouton INTERAGIR, clavier.
const KEY_DIRS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', w: 'up', s: 'down', a: 'left', d: 'right', q: 'left' };
const ACTION_KEYS = new Set([' ', 'Enter', 'e', 'z']);

export function initInput({ onAction, onMenu, route }) {
  const held = [];          // directions clavier tenues, la dernière gagne
  let padDir = null;
  const dpad = document.getElementById('dpad');
  const parts = { up: dpad.querySelector('.up'), down: dpad.querySelector('.down'), left: dpad.querySelector('.left'), right: dpad.querySelector('.right') };

  const setPad = d => {
    if (d === padDir) return;
    padDir = d;
    for (const [k, el] of Object.entries(parts)) el.classList.toggle('on', k === d);
  };
  const dirFromEvent = e => {
    const r = dpad.getBoundingClientRect();
    const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    if (Math.hypot(dx, dy) < r.width * 0.12) return null;
    return Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
  };
  let padPointer = null;
  dpad.addEventListener('pointerdown', e => {
    e.preventDefault();
    padPointer = e.pointerId;
    try { dpad.setPointerCapture(e.pointerId); } catch { /* ignoré */ }
    setPad(dirFromEvent(e));
  });
  dpad.addEventListener('pointermove', e => { if (e.pointerId === padPointer) setPad(dirFromEvent(e)); });
  const end = e => { if (e.pointerId === padPointer) { padPointer = null; setPad(null); } };
  dpad.addEventListener('pointerup', end);
  dpad.addEventListener('pointercancel', end);
  dpad.addEventListener('lostpointercapture', end);

  const act = document.getElementById('btn-act');
  act.addEventListener('pointerdown', e => { e.preventDefault(); onAction(); });
  document.getElementById('btn-menu').addEventListener('click', () => onMenu());

  window.addEventListener('keydown', e => {
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    if (KEY_DIRS[k] || ACTION_KEYS.has(k)) e.preventDefault();
    const target = route();
    if (target !== 'world') {
      if (!e.repeat) target?.key?.(k);
      return;
    }
    if (KEY_DIRS[k]) { const d = KEY_DIRS[k]; const i = held.indexOf(d); if (i >= 0) held.splice(i, 1); held.push(d); }
    else if (ACTION_KEYS.has(k) && !e.repeat) onAction();
    else if (k === 'Escape' || k === 'm') onMenu();
  });
  window.addEventListener('keyup', e => {
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    const d = KEY_DIRS[k];
    if (d) { const i = held.indexOf(d); if (i >= 0) held.splice(i, 1); }
  });
  window.addEventListener('blur', () => { held.length = 0; setPad(null); });

  // Anti-zoom accidentel (iOS ignore parfois user-scalable=no)
  document.addEventListener('gesturestart', e => e.preventDefault());
  document.addEventListener('dblclick', e => e.preventDefault());
  let lastTouch = 0;
  document.addEventListener('touchend', e => {
    const now = Date.now();
    if (now - lastTouch < 300 && !e.target.closest('button, .menu-card')) e.preventDefault();
    lastTouch = now;
  }, { passive: false });

  return {
    dir: () => padDir || held[held.length - 1] || null,
    clearHeld: () => { held.length = 0; },
  };
}
