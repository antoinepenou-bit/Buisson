// Rendu Canvas 2D : caméra qui suit le joueur, tri en profondeur, teinte jour/nuit.
import { TILE } from '../data/maps.js';
import { drawGroundTile, drawWaterFx, drawPine, drawChar, PROPS } from './sprites.js';

const FLAT = new Set(['paint', 'towel', 'boules', 'barsign']);
const VIEW_TILES_W = 14; // largeur visible visée, en tuiles

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.ground = document.createElement('canvas');
    this.mapId = null;
    this.resize();
  }

  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const r = this.canvas.getBoundingClientRect();
    this.canvas.width = Math.max(1, Math.round(r.width * dpr));
    this.canvas.height = Math.max(1, Math.round(r.height * dpr));
    this.scale = Math.max(2, Math.round(this.canvas.width / (VIEW_TILES_W * TILE)));
    this.viewW = this.canvas.width / this.scale;
    this.viewH = this.canvas.height / this.scale;
  }

  /** Pré-rendu du sol de la carte dans un canvas hors-écran (une seule fois par carte). */
  setMap(map) {
    if (this.mapId === map.id) return;
    this.mapId = map.id;
    const g = this.ground;
    g.width = map.w * TILE; g.height = map.h * TILE;
    const c = g.getContext('2d');
    for (let y = 0; y < map.h; y++) for (let x = 0; x < map.w; x++) drawGroundTile(c, map.tiles[y][x], x, y, map);
  }

  draw(game, t) {
    const { ctx: c, scale } = this;
    const map = game.map;
    this.setMap(map);
    const mw = map.w * TILE, mh = map.h * TILE;
    const p = game.player;
    const cx = p.px + 8, cy = p.py + 4;
    const camX = mw <= this.viewW ? (mw - this.viewW) / 2 : Math.min(Math.max(cx - this.viewW / 2, 0), mw - this.viewW);
    const camY = mh <= this.viewH ? (mh - this.viewH) / 2 : Math.min(Math.max(cy - this.viewH / 2, 0), mh - this.viewH);

    c.setTransform(1, 0, 0, 1, 0, 0);
    c.imageSmoothingEnabled = false;
    c.fillStyle = '#17382b';
    c.fillRect(0, 0, this.canvas.width, this.canvas.height);
    c.setTransform(scale, 0, 0, scale, Math.round(-camX * scale), Math.round(-camY * scale));
    c.imageSmoothingEnabled = false;
    c.drawImage(this.ground, 0, 0);

    const x0 = Math.max(0, Math.floor(camX / TILE) - 1), y0 = Math.max(0, Math.floor(camY / TILE) - 1);
    const x1 = Math.min(map.w - 1, Math.ceil((camX + this.viewW) / TILE) + 1), y1 = Math.min(map.h - 1, Math.ceil((camY + this.viewH) / TILE) + 2);
    drawWaterFx(c, map, t, x0, y0, x1, y1);
    this.drawExits(c, map, t);

    const ctx = { cond: game.conditions() };
    for (const pr of map.props) if (FLAT.has(pr.type)) PROPS[pr.type](c, pr, t, ctx);

    // Liste triée par « pied » (y bas) pour la profondeur
    const list = [];
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      if (map.tiles[y][x] === 'T') list.push({ z: y * TILE + 15, f: () => drawPine(c, x, y, t) });
    }
    for (const pr of map.props) {
      if (FLAT.has(pr.type)) continue;
      list.push({ z: (pr.y + (pr.h || 1)) * TILE - 1, f: () => PROPS[pr.type](c, pr, t, ctx) });
    }
    for (const n of game.visibleNpcs()) {
      list.push({ z: n.py + 14, f: () => drawChar(c, n.px, n.py, n.look, n.facing, 0, n.emote, t) });
    }
    list.push({ z: p.py + 14.5, f: () => drawChar(c, p.px, p.py, p.look, p.facing, p.frame, null, t) });
    list.sort((a, b) => a.z - b.z);
    for (const d of list) d.f();

    // Repère au-dessus de la cible d'interaction
    const tg = game.target;
    if (tg && !game.busy) {
      const bob = Math.round(Math.sin(t * 6) * 1.5);
      const mx = tg.tx * TILE + 5, my = tg.ty * TILE - (tg.kind === 'npc' ? 24 : 10) + bob;
      c.fillStyle = '#2a1d14'; c.fillRect(mx - 1, my - 1, 8, 5); c.fillRect(mx + 1, my + 4, 4, 2);
      c.fillStyle = '#f3a648'; c.fillRect(mx, my, 6, 3); c.fillRect(mx + 2, my + 3, 2, 2);
    }

    // Teinte horaire
    c.setTransform(1, 0, 0, 1, 0, 0);
    for (const [col, a] of tint(game.s.time)) {
      if (a <= 0) continue;
      c.globalAlpha = a; c.fillStyle = col; c.fillRect(0, 0, this.canvas.width, this.canvas.height);
    }
    c.globalAlpha = 1;
  }

  drawExits(c, map, t) {
    const pulse = (Math.sin(t * 4) + 1) / 2;
    for (const e of map.exits) {
      for (let j = 0; j < e.h; j++) for (let i = 0; i < e.w; i++) {
        const X = (e.x + i) * TILE, Y = (e.y + j) * TILE;
        c.globalAlpha = 0.35 + pulse * 0.4;
        c.fillStyle = '#fff8ea';
        const o = Math.round(pulse * 2);
        if (e.dir === 'up') { c.fillRect(X + 5, Y + 6 - o, 6, 2); c.fillRect(X + 7, Y + 4 - o, 2, 2); }
        if (e.dir === 'down') { c.fillRect(X + 5, Y + 8 + o, 6, 2); c.fillRect(X + 7, Y + 10 + o, 2, 2); }
        if (e.dir === 'left') { c.fillRect(X + 6 - o, Y + 5, 2, 6); c.fillRect(X + 4 - o, Y + 7, 2, 2); }
        if (e.dir === 'right') { c.fillRect(X + 8 + o, Y + 5, 2, 6); c.fillRect(X + 10 + o, Y + 7, 2, 2); }
      }
    }
    c.globalAlpha = 1;
  }
}

/** Calques de couleur selon l'heure : coucher de soleil orange, nuit bleue. */
function tint(time) {
  const t = time % 1440;
  const lerp = (a, b, k) => a + (b - a) * Math.min(1, Math.max(0, k));
  if (t >= 420 && t < 1020) return [];
  if (t >= 1020 && t < 1170) return [['#e8743b', lerp(0, 0.2, (t - 1020) / 150)]];
  if (t >= 1170 && t < 1290) { const k = (t - 1170) / 120; return [['#e8743b', lerp(0.2, 0.05, k)], ['#0d1a3a', lerp(0, 0.45, k)]]; }
  if (t >= 360 && t < 420) { const k = (t - 360) / 60; return [['#0d1a3a', lerp(0.4, 0, k)], ['#f3a648', lerp(0.1, 0, k)]]; }
  return [['#0d1a3a', 0.5]];
}
