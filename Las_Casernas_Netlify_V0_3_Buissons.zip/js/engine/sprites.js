// Dessin pixel-art procédural (aucune image à charger). Coordonnées en pixels logiques (1 tuile = 16 px).
import { TILE } from '../data/maps.js';

const rnd = (x, y, k = 0) => { const v = Math.sin(x * 127.1 + y * 311.7 + k * 74.7) * 43758.5453; return v - Math.floor(v); };
const R = (c, col, x, y, w, h) => { c.fillStyle = col; c.fillRect(x, y, w, h); };

// ------------------------------------------------------------------ TERRAIN
const GROUND = {
  a: '#7a776f', n: '#b78a55', g: '#8aab5e', s: '#edd39c', d: '#e1c283', p: '#dcc08a',
  w: '#1f6491', r: '#c97b4f', b: '#a8723f', D: '#8a5a2f', W: '#efe3c8', T: '#b78a55', F: '#edd39c', x: '#31543d',
};

export function drawGroundTile(c, t, tx, ty, map) {
  const X = tx * TILE, Y = ty * TILE;
  let base = t;
  if (t === 'F') base = ty >= 16 && map.beach ? 'd' : 's';
  if (t === 'T' && map.id === 'camping') base = 'g';
  R(c, GROUND[base] || '#f0f', X, Y, TILE, TILE);
  const r1 = rnd(tx, ty), r2 = rnd(tx, ty, 1), r3 = rnd(tx, ty, 2);
  switch (base) {
    case 'a':
      for (let i = 0; i < 5; i++) R(c, i % 2 ? '#6c6961' : '#87847b', X + Math.floor(rnd(tx, ty, i + 3) * 15), Y + Math.floor(rnd(tx, ty, i + 9) * 15), 1, 1);
      if (r1 > 0.85) { c.globalAlpha = 0.35; R(c, '#c9a463', X + 2, Y + 4, 9, 5); R(c, '#c9a463', X + 5, Y + 2, 5, 9); c.globalAlpha = 1; }
      break;
    case 'n': case 'T':
      for (let i = 0; i < 6; i++) {
        const nx = X + Math.floor(rnd(tx, ty, i + 3) * 13), ny = Y + Math.floor(rnd(tx, ty, i + 11) * 15);
        R(c, i % 2 ? '#9a6d3d' : '#cfa46a', nx, ny, 3, 1);
      }
      if (r1 > 0.8) R(c, '#7a5230', X + 6, Y + 9, 3, 2); // pomme de pin
      break;
    case 'g':
      for (let i = 0; i < 4; i++) {
        const gx = X + Math.floor(rnd(tx, ty, i + 3) * 13), gy = Y + 2 + Math.floor(rnd(tx, ty, i + 7) * 12);
        R(c, '#6f9149', gx, gy, 1, 2); R(c, '#6f9149', gx + 2, gy, 1, 2); R(c, '#9dbd6c', gx + 1, gy - 1, 1, 2);
      }
      if (r2 > 0.9) { R(c, '#f3d36b', X + 9, Y + 5, 2, 2); R(c, '#fff8ea', X + 4, Y + 11, 1, 1); }
      break;
    case 'x':
      R(c, '#31543d', X, Y, TILE, TILE);
      R(c, '#52734a', X + 1, Y + 3, 7, 7); R(c, '#44683f', X + 8, Y + 1, 7, 9);
      R(c, '#6b8a55', X + 5, Y + 9, 8, 6);
      R(c, '#8aa164', X + ((tx * 7 + ty * 3) % 11), Y + ((tx * 5 + ty * 9) % 12), 2, 2);
      break;
    case 's':
      for (let i = 0; i < 5; i++) R(c, i % 2 ? '#d9b97c' : '#f8e6bd', X + Math.floor(rnd(tx, ty, i + 3) * 15), Y + Math.floor(rnd(tx, ty, i + 13) * 15), 1, 1);
      if (r3 > 0.93) { R(c, '#f4f1ea', X + 7, Y + 8, 3, 2); R(c, '#d9a0a0', X + 8, Y + 8, 1, 1); } // coquillage
      break;
    case 'd':
      R(c, '#cfae6f', X + 1, Y + 4 + Math.floor(r1 * 3), 9, 1);
      R(c, '#cfae6f', X + 6, Y + 11 + Math.floor(r2 * 3), 9, 1);
      R(c, '#efd59f', X + 2, Y + 3 + Math.floor(r1 * 3), 7, 1);
      break;
    case 'p':
      R(c, '#e6cd9b', X, Y, TILE, TILE);
      for (let i = 0; i < 3; i++) R(c, '#c8a873', X + Math.floor(rnd(tx, ty, i + 3) * 14), Y + Math.floor(rnd(tx, ty, i + 5) * 14), 2, 1);
      break;
    case 'w':
      R(c, '#2b77a8', X + Math.floor(r1 * 8), Y + 4, 6, 1);
      R(c, '#1a5780', X + Math.floor(r2 * 8) + 4, Y + 11, 5, 1);
      break;
    case 'r':
      R(c, '#a65f3b', X, Y + 7, TILE, 1); R(c, '#a65f3b', X, Y + 15, TILE, 1);
      R(c, '#a65f3b', X + (ty % 2 ? 7 : 15), Y, 1, 7); R(c, '#a65f3b', X + (ty % 2 ? 15 : 7), Y + 8, 1, 7);
      R(c, '#d68c5f', X + 2, Y + 2, 2, 1);
      break;
    case 'b': case 'D':
      for (let i = 0; i < 4; i++) R(c, base === 'D' ? '#6e4524' : '#8a5a2f', X, Y + i * 4 + 3, TILE, 1);
      R(c, '#8a5a2f', X + ((tx * 5 + ty * 3) % 12) + 2, Y, 1, 3);
      R(c, '#8a5a2f', X + ((tx * 7 + ty) % 12) + 2, Y + 8, 1, 3);
      break;
    case 'W': {
      const front = ty === 9;
      R(c, '#efe3c8', X, Y, TILE, TILE);
      R(c, '#6e3a22', X, Y, TILE, 2);
      R(c, '#6e3a22', X, Y + 14, TILE, 2);
      R(c, '#6e3a22', X + 7, Y + 2, 2, 12);
      if (front) { R(c, '#6e3a22', X + 1, Y + 4, 2, 2); R(c, '#6e3a22', X + 3, Y + 6, 2, 2); R(c, '#6e3a22', X + 5, Y + 8, 2, 2); }
      if ((tx + ty) % 3 === 0 && !front) R(c, '#d8c8a8', X + 10, Y + 5, 3, 3);
      break;
    }
  }
  if (t === 'F') drawFence(c, X, Y);
}

function drawFence(c, X, Y) {
  // Ganivelle landaise : piquets de châtaignier liés par du fil de fer
  for (let i = 0; i < 5; i++) {
    const sx = X + i * 3 + 1;
    R(c, '#7d5a35', sx, Y + 2, 2, 13);
    R(c, '#a8804f', sx, Y + 2, 1, 12);
  }
  R(c, '#5e4a38', X, Y + 5, TILE, 1);
  R(c, '#5e4a38', X, Y + 12, TILE, 1);
}

/** Écume animée et vagues sur l'eau (dessiné chaque image). */
export function drawWaterFx(c, map, t, x0, y0, x1, y1) {
  for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
    if (map.tiles[ty]?.[tx] !== 'w') continue;
    const X = tx * TILE, Y = ty * TILE;
    const off = Math.floor((t * 6 + rnd(tx, ty) * 16) % 16);
    R(c, '#4a92c2', X + off - 3, Y + 7, 4, 1);
    const below = map.tiles[ty + 1]?.[tx];
    if (below && below !== 'w') {
      const k = Math.sin(t * 2 + tx * 0.9);
      R(c, '#9fd0ea', X, Y + 11 + Math.round(k), TILE, 2);
      R(c, '#f4f8f6', X, Y + 13 + Math.round(k), TILE, 3);
      R(c, '#f4f8f6', X + Math.floor((tx * 5) % 12), Y + 10 + Math.round(k), 3, 1);
    }
  }
  if (!map.beach) return;
  // Une ligne de vague qui avance vers le bord
  const period = 5;
  const p = (t % period) / period;
  const wy = Math.floor(16 + p * 80);
  c.globalAlpha = Math.sin(p * Math.PI) * 0.9;
  for (let x = 0; x < map.w * TILE; x += 4) {
    const h = Math.sin(x * 0.07 + t) > 0.2 ? 2 : 1;
    R(c, '#f4f8f6', x, wy + Math.round(Math.sin(x * 0.05) * 2), 3, h);
  }
  c.globalAlpha = 1;
}

// ------------------------------------------------------------------ ARBRES
export function drawPine(c, tx, ty, t) {
  const X = tx * TILE, Y = ty * TILE;
  const sway = Math.round(Math.sin(t * 0.8 + tx) * 0.6);
  c.fillStyle = 'rgba(30,40,20,.28)';
  c.beginPath(); c.ellipse(X + 8, Y + 14, 9, 3, 0, 0, Math.PI * 2); c.fill();
  R(c, '#5a3a22', X + 7, Y - 8, 3, 23);
  R(c, '#7a5230', X + 7, Y - 8, 1, 23);
  R(c, '#5a3a22', X + 9, Y - 4, 3, 1);
  const cx = X + 8 + sway, cy = Y - 14;
  const blob = (bx, by, w, h, col) => R(c, col, cx + bx, cy + by, w, h);
  blob(-10, -2, 20, 7, '#224632'); blob(-8, -5, 16, 3, '#224632'); blob(-12, 1, 6, 4, '#224632'); blob(6, 1, 6, 4, '#224632');
  blob(-8, -4, 9, 4, '#2f5d3f'); blob(1, -3, 8, 4, '#2f5d3f'); blob(-10, 1, 6, 2, '#2f5d3f'); blob(4, 1, 6, 2, '#2f5d3f');
  blob(-6, -4, 4, 1, '#4b8360'); blob(3, -3, 4, 1, '#4b8360'); blob(-9, 1, 3, 1, '#4b8360');
}

// ------------------------------------------------------------------ PERSONNAGES
export function drawChar(c, X, Y, L, facing = 'down', frame = 0, emote = null, t = 0) {
  X = Math.round(X); Y = Math.round(Y);
  if (L.pose === 'lying') return drawLying(c, X, Y, L);
  const bob = frame % 2 === 1 ? -1 : 0;
  c.fillStyle = 'rgba(0,0,0,.25)';
  c.beginPath(); c.ellipse(X + 8, Y + 15, 5, 2, 0, 0, Math.PI * 2); c.fill();
  const pants = L.wetsuit ? '#1f2a33' : L.pants;
  // Jambes
  const lUp = frame === 1 ? 1 : 0, rUp = frame === 3 ? 1 : 0;
  R(c, pants, X + 5, Y + 11, 2, 4 - lUp); R(c, pants, X + 9, Y + 11, 2, 4 - rUp);
  R(c, L.skin, X + 5, Y + 14 - lUp, 2, 1); R(c, L.skin, X + 9, Y + 14 - rUp, 2, 1);
  const y = Y + bob;
  // Torse et bras
  const shirt = L.wetsuit ? '#1f2a33' : L.shirt;
  R(c, shirt, X + 4, y + 5, 8, 7);
  if (L.wetsuit) R(c, L.wetsuit, X + 4, y + 7, 8, 1);
  if (L.apron) R(c, '#f4f1ea', X + 5, y + 7, 6, 5), R(c, '#c9b99a', X + 5, y + 7, 6, 1);
  if (L.scarf) R(c, L.scarf, X + 4, y + 5, 8, 2);
  const armSwing = facing === 'left' || facing === 'right' ? (frame === 1 ? 1 : frame === 3 ? -1 : 0) : 0;
  const armC = L.wetsuit ? '#1f2a33' : L.skin;
  if (facing !== 'right') R(c, armC, X + 3, y + 6 + armSwing, 1, 5);
  if (facing !== 'left') R(c, armC, X + 12, y + 6 - armSwing, 1, 5);
  R(c, shirt, X + 3, y + 5, 1, 2); R(c, shirt, X + 12, y + 5, 1, 2);
  // Tête
  R(c, L.skin, X + 4, y - 3, 8, 8);
  R(c, 'rgba(0,0,0,.08)', X + 4, y + 4, 8, 1);
  drawHair(c, X, y, L, facing);
  // Visage
  if (facing !== 'up') {
    const ink = '#2a1d14';
    if (facing === 'down') {
      R(c, ink, X + 6, y, 1, 2); R(c, ink, X + 9, y, 1, 2);
      R(c, '#b0664a', X + 7, y + 3, 2, 1);
    } else {
      const ex = facing === 'left' ? X + 5 : X + 10;
      R(c, ink, ex, y, 1, 2);
      R(c, '#b0664a', facing === 'left' ? X + 4 : X + 11, y + 3, 1, 1);
    }
    if (L.beard) {
      const bc = L.beardColor || L.hair;
      if (facing === 'down') { R(c, bc, X + 4, y + 2, 2, 3); R(c, bc, X + 10, y + 2, 2, 3); R(c, bc, X + 5, y + 4, 6, 2); }
      else R(c, bc, facing === 'left' ? X + 4 : X + 8, y + 2, 4, 4);
    }
    if (L.moustache) R(c, L.beardColor || L.hair, facing === 'down' ? X + 6 : (facing === 'left' ? X + 4 : X + 9), y + 2, facing === 'down' ? 4 : 3, 1);
    if (L.glasses) {
      if (facing === 'down') { R(c, ink, X + 5, y - 1, 3, 1); R(c, ink, X + 8, y - 1, 3, 1); R(c, ink, X + 5, y + 1, 3, 1); R(c, ink, X + 8, y + 1, 3, 1); }
      else R(c, ink, facing === 'left' ? X + 4 : X + 9, y - 1, 3, 1);
    }
    if (L.sunglasses) R(c, '#1a1a1a', facing === 'down' ? X + 5 : (facing === 'left' ? X + 4 : X + 9), y, facing === 'down' ? 6 : 3, 2);
    if (L.earrings) { R(c, '#f3d36b', facing === 'right' ? X + 6 : X + 4, y + 3, 1, 1); if (facing === 'down') R(c, '#f3d36b', X + 11, y + 3, 1, 1); }
  }
  // Couvre-chefs
  if (L.cap) {
    R(c, L.cap, X + 4, y - 5, 8, 3);
    if (facing === 'down') R(c, shade(L.cap), X + 4, y - 2, 8, 1);
    if (facing === 'left') R(c, shade(L.cap), X + 2, y - 3, 3, 1);
    if (facing === 'right') R(c, shade(L.cap), X + 11, y - 3, 3, 1);
  }
  if (L.hat) { R(c, L.hat, X + 2, y - 3, 12, 2); R(c, L.hat, X + 5, y - 6, 6, 3); R(c, '#c4472f', X + 5, y - 4, 6, 1); }
  if (L.beret) { R(c, L.beret, X + 3, y - 5, 10, 3); R(c, L.beret, X + 7, y - 6, 2, 1); }
  if (L.headband) R(c, L.headband, X + 4, y - 3, 8, 1);
  if (emote) drawEmote(c, X, Y, emote, t);
}

function drawHair(c, X, y, L, facing) {
  const h = L.hair;
  switch (L.style) {
    case 'bald':
      R(c, h, X + 4, y, 1, 3); R(c, h, X + 11, y, 1, 3); R(c, 'rgba(255,255,255,.35)', X + 7, y - 2, 2, 1);
      if (facing === 'up') R(c, h, X + 4, y + 1, 8, 2);
      return;
    case 'curly':
      R(c, h, X + 3, y - 5, 10, 3); R(c, h, X + 3, y - 2, 2, 3); R(c, h, X + 11, y - 2, 2, 3);
      R(c, shade(h), X + 5, y - 5, 1, 1); R(c, shade(h), X + 9, y - 4, 1, 1);
      if (facing === 'up') R(c, h, X + 3, y - 3, 10, 7);
      return;
    default: {
      R(c, h, X + 4, y - 5, 8, 3);
      R(c, h, X + 4, y - 2, 1, 2); R(c, h, X + 11, y - 2, 1, 2);
      if (facing === 'left') R(c, h, X + 8, y - 2, 4, 3);
      if (facing === 'right') R(c, h, X + 4, y - 2, 4, 3);
      if (facing === 'up') R(c, h, X + 4, y - 3, 8, 7);
      if (L.style === 'long') {
        R(c, h, X + 3, y - 3, 2, 10); R(c, h, X + 11, y - 3, 2, 10);
        if (facing === 'up') R(c, h, X + 4, y + 3, 8, 4);
      }
      if (L.style === 'bun') R(c, h, X + 6, y - 7, 4, 2);
      if (L.style === 'manbun') R(c, h, X + 7, y - 7, 3, 2);
      if (L.style === 'ponytail') {
        if (facing === 'left') R(c, h, X + 12, y - 2, 2, 6);
        else if (facing === 'right') R(c, h, X + 2, y - 2, 2, 6);
        else if (facing === 'up') R(c, h, X + 7, y + 3, 2, 5);
      }
      if (L.style === 'short' && facing === 'down') R(c, shade(h), X + 6, y - 3, 3, 1);
    }
  }
}

function drawLying(c, X, Y, L) {
  R(c, L.skin, X + 1, Y + 5, 6, 6);
  R(c, L.hair, X + 1, Y + 4, 3, 7);
  if (L.sunglasses) R(c, '#1a1a1a', X + 4, Y + 6, 2, 4);
  R(c, L.skin, X + 7, Y + 5, 9, 6);
  R(c, L.pants, X + 11, Y + 5, 3, 6);
  R(c, 'rgba(0,0,0,.08)', X + 7, Y + 10, 9, 1);
}

function drawEmote(c, X, Y, ch, t) {
  const by = Y - 20 + Math.round(Math.sin(t * 5) * 1.5);
  R(c, '#2a1d14', X + 3, by - 1, 11, 11);
  R(c, '#fff8ea', X + 4, by, 9, 9);
  R(c, '#fff8ea', X + 7, by + 9, 3, 2); R(c, '#2a1d14', X + 7, by + 11, 3, 1);
  c.fillStyle = ch === '!' ? '#c4472f' : ch === '€' ? '#2f6b4f' : '#1d5f8a';
  c.font = '8px Silkscreen, monospace'; c.textAlign = 'center'; c.textBaseline = 'middle';
  c.fillText(ch, X + 8.5, by + 5);
}

function shade(hex, k = 0.75) {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.floor(((n >> 16) & 255) * k), g = Math.floor(((n >> 8) & 255) * k), b = Math.floor((n & 255) * k);
  return `rgb(${r},${g},${b})`;
}

// ------------------------------------------------------------------ PROPS
const VAN_COLORS = { orange: '#d9682f', green: '#4f8a5b', blue: '#3d7fb0' };
const CAR_COLORS = { blue: '#5b8fb8', red: '#c4472f', yellow: '#e8b23b' };
const TENT_COLORS = { orange: '#e8743b', blue: '#3d8fbf', green: '#4f8a5b', red: '#c4472f', yellow: '#e8b23b' };

function text(c, str, x, y, col, size = 5, align = 'center') {
  c.fillStyle = col; c.font = `${size}px Silkscreen, monospace`; c.textAlign = align; c.textBaseline = 'middle';
  c.fillText(str, x, y);
}

export const PROPS = {
  van(c, p, t) {
    const X = p.x * TILE, Y = p.y * TILE, w = p.w * TILE, body = VAN_COLORS[p.color] || '#d9682f';
    c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(X + 2, Y + 26, w - 4, 6);
    R(c, '#f3e6c4', X + 2, Y + 1, w - 4, 14); R(c, '#f3e6c4', X + 1, Y + 3, w - 2, 12);
    R(c, body, X + 1, Y + 15, w - 2, 12);
    R(c, shade(body), X + 1, Y + 25, w - 2, 2);
    R(c, '#d6c6a0', X + 2, Y + 1, w - 4, 2);
    // Fenêtres
    for (let i = 0; i < 4; i++) {
      R(c, '#2b4e66', X + 5 + i * 10, Y + 5, 8, 7);
      R(c, '#4f7a96', X + 5 + i * 10, Y + 5, 3, 2);
      if (p.board) R(c, '#f3a648', X + 5 + i * 10, Y + 9, 8, 3);
    }
    // V avant + phares
    R(c, '#f3e6c4', X + w - 7, Y + 15, 2, 6); R(c, '#f3e6c4', X + w - 5, Y + 19, 2, 4);
    R(c, '#fff3b0', X + w - 3, Y + 18, 2, 3);
    R(c, '#c0c0b8', X + 1, Y + 22, w - 2, 1);
    // Roues
    for (const wx of [X + 6, X + w - 15]) { R(c, '#1f1f1f', wx, Y + 24, 9, 7); R(c, '#9a9a92', wx + 3, Y + 26, 3, 3); }
    if (p.board) {
      R(c, '#f4f1ea', X + 5, Y - 3, w - 10, 4); R(c, '#e8743b', X + 5, Y - 2, w - 10, 1);
      R(c, '#f4f1ea', X + 3, Y - 2, 2, 2); R(c, '#2a1d14', X + 8, Y + 1, 2, 2); R(c, '#2a1d14', X + w - 10, Y + 1, 2, 2);
    }
    if (p.hood) {
      R(c, shade(body), X + w - 12, Y + 8, 11, 7);
      R(c, body, X + w - 13, Y - 2, 12, 10);
      R(c, '#f3e6c4', X + w - 12, Y - 1, 10, 2);
      R(c, '#3a3a3a', X + w - 11, Y + 10, 8, 4);
      c.globalAlpha = 0.5;
      const s = (t * 0.6) % 1;
      R(c, '#e8e8e0', X + w - 8 + Math.round(Math.sin(t * 3) * 2), Y - 4 - s * 10, 3, 3);
      c.globalAlpha = 1;
    }
  },
  car(c, p) {
    const X = p.x * TILE, Y = p.y * TILE, w = p.w * TILE, col = CAR_COLORS[p.color] || '#5b8fb8';
    c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(X + 2, Y + 24, w - 4, 6);
    R(c, col, X + 2, Y + 12, w - 4, 13);
    R(c, col, X + 10, Y + 3, w - 22, 10);
    R(c, '#2b4e66', X + 12, Y + 5, 10, 6); R(c, '#2b4e66', X + 24, Y + 5, w - 38, 6);
    R(c, shade(col), X + 2, Y + 22, w - 4, 3);
    R(c, '#c0c0b8', X + 1, Y + 19, 3, 2); R(c, '#c0c0b8', X + w - 4, Y + 19, 3, 2);
    R(c, '#fff3b0', X + w - 4, Y + 14, 2, 3);
    R(c, '#6b4a2a', X + 12, Y + 1, w - 26, 2);
    for (const wx of [X + 6, X + w - 15]) { R(c, '#1f1f1f', wx, Y + 22, 9, 7); R(c, '#9a9a92', wx + 3, Y + 24, 3, 3); }
  },
  cafe(c, p, t) {
    const X = p.x * TILE, Y = p.y * TILE, w = p.w * TILE;
    c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(X + 2, Y + 28, w - 4, 4);
    // Momo derrière le comptoir
    drawChar(c, X + 16, Y + 6, { skin: '#c98d5e', hair: '#2a1d14', style: 'curly', shirt: '#e8743b', pants: '#2a1d14', moustache: true }, 'down', 0);
    R(c, '#9b6a3c', X + 1, Y + 16, w - 2, 14);
    for (let i = 0; i < 4; i++) R(c, '#7d5430', X + 1, Y + 18 + i * 3, w - 2, 1);
    R(c, '#c99a63', X, Y + 14, w, 3);
    R(c, '#6b6b6b', X + 32, Y + 6, 9, 9); R(c, '#9a9a92', X + 33, Y + 7, 7, 3); R(c, '#2a1d14', X + 35, Y + 12, 3, 2);
    R(c, '#f4f1ea', X + 6, Y + 11, 3, 3); R(c, '#f4f1ea', X + 10, Y + 11, 3, 3);
    c.globalAlpha = 0.5; R(c, '#f4f1ea', X + 7, Y + 8 - Math.floor((t * 4) % 3), 1, 2); c.globalAlpha = 1;
    // Auvent rayé
    for (let i = 0; i < w; i += 6) { R(c, (i / 6) % 2 ? '#f6e7c8' : '#e8743b', X + i, Y - 6, 6, 8); R(c, (i / 6) % 2 ? '#f6e7c8' : '#e8743b', X + i + 1, Y + 2, 4, 2); }
    R(c, '#7d5430', X + 1, Y - 6, 2, 22); R(c, '#7d5430', X + w - 3, Y - 6, 2, 22);
    // Ardoise
    R(c, '#2a2a2a', X + 4, Y + 18, 14, 9); text(c, 'CAFÉ', X + 11, Y + 21, '#f6e7c8', 4); text(c, '2€', X + 11, Y + 25, '#f3a648', 4);
  },
  table(c, p) {
    const X = p.x * TILE, Y = p.y * TILE;
    c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(X + 2, Y + 11, 12, 4);
    R(c, '#7d5430', X + 3, Y + 8, 2, 6); R(c, '#7d5430', X + 11, Y + 8, 2, 6);
    R(c, '#b98a55', X + 1, Y + 3, 14, 6); R(c, '#cfa46a', X + 1, Y + 3, 14, 1);
    R(c, '#f4f1ea', X + 4, Y + 4, 2, 2); R(c, '#c4472f', X + 9, Y + 4, 3, 2);
  },
  chair(c, p) {
    const X = p.x * TILE, Y = p.y * TILE;
    R(c, '#2f6b4f', X + 5, Y + 4, 6, 2); R(c, '#2f6b4f', X + 5, Y + 7, 6, 3);
    R(c, '#5a3a22', X + 5, Y + 10, 1, 4); R(c, '#5a3a22', X + 10, Y + 10, 1, 4);
  },
  paint(c, p) {
    const X = p.x * TILE, Y = p.y * TILE;
    R(c, '#e6e2d6', X + 7, Y + 1, 2, p.h * TILE - 2);
  },
  boards(c, p) {
    const X = p.x * TILE, Y = p.y * TILE;
    R(c, '#f4f1ea', X + 2, Y - 6, 4, 34); R(c, '#3d8fbf', X + 3, Y - 6, 2, 34);
    R(c, '#f3a648', X + 8, Y - 2, 4, 30); R(c, '#f4f1ea', X + 9, Y - 2, 1, 30);
    R(c, '#2a1d14', X + 1, Y + 27, 13, 2);
  },
  sign(c, p) {
    const X = p.x * TILE, Y = p.y * TILE;
    R(c, '#5a3a22', X + 7, Y + 4, 2, 11);
    R(c, '#2a1d14', X - 3, Y - 4, 22, 10);
    R(c, '#f6e7c8', X - 2, Y - 3, 20, 8);
    const arrow = { up: '↑', down: '↓', left: '←', right: '→' }[p.arrow] || '';
    text(c, p.text.length > 6 ? p.text.slice(0, 7) : p.text, X + 8, Y, '#1f4d3a', 4);
    if (arrow) text(c, arrow, X + 8, Y + 9, '#e8743b', 6);
  },
  building(c, p) {
    const X = p.x * TILE, Y = p.y * TILE, w = p.w * TILE, h = p.h * TILE;
    c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(X + 2, Y + h - 2, w, 4);
    const acc = p.style === 'accueil';
    // Murs
    R(c, acc ? '#efe3c8' : '#d4dfe0', X + 1, Y + 14, w - 2, h - 14);
    if (acc) {
      R(c, '#6e3a22', X + 1, Y + 14, w - 2, 2); R(c, '#6e3a22', X + 1, Y + h - 2, w - 2, 2);
      for (const bx of [X + 1, X + 20, X + w - 3]) R(c, '#6e3a22', bx, Y + 14, 2, h - 14);
      R(c, '#6e3a22', X + 4, Y + 20, 2, 2); R(c, '#6e3a22', X + 7, Y + 23, 2, 2); R(c, '#6e3a22', X + 10, Y + 26, 2, 2);
    }
    // Toit
    if (acc) {
      R(c, '#b5532f', X - 2, Y + 2, w + 4, 13);
      for (let i = 0; i < 4; i++) R(c, '#8f3f22', X - 2, Y + 4 + i * 3, w + 4, 1);
      R(c, '#d06a3c', X - 2, Y + 2, w + 4, 2);
    } else {
      R(c, '#6b8a7a', X - 1, Y + 8, w + 2, 7); R(c, '#86a596', X - 1, Y + 8, w + 2, 2);
    }
    // Porte / fenêtres
    if (acc) {
      R(c, '#5a3a22', X + 24, Y + 28, 10, 20 - 0); R(c, '#f3d36b', X + 31, Y + 37, 1, 2);
      R(c, '#2b4e66', X + 40, Y + 22, 14, 10); R(c, '#e8743b', X + 39, Y + 32, 16, 3);
      R(c, '#c4472f', X + 41, Y + 31, 2, 1); R(c, '#f3d36b', X + 46, Y + 31, 2, 1);
      R(c, '#1f4d3a', X + 6, Y + 31, 14, 7); text(c, 'ACCUEIL', X + 13, Y + 34.5, '#f6e7c8', 3.2);
    } else {
      R(c, '#3d6b8a', X + 8, Y + 26, 10, 22); R(c, '#3d6b8a', X + 44, Y + 26, 10, 22);
      text(c, '♀', X + 13, Y + 31, '#f6e7c8', 6); text(c, '♂', X + 49, Y + 31, '#f6e7c8', 6);
      R(c, '#1d5f8a', X + 20, Y + 17, 24, 8); text(c, 'DOUCHES', X + 32, Y + 21, '#f6e7c8', 3.6);
      R(c, '#9a9a92', X + 26, Y + 30, 2, 12); R(c, '#9a9a92', X + 26, Y + 30, 8, 2);
      c.globalAlpha = 0.5; R(c, '#9fd0ea', X + 32, Y + 33, 1, 6); R(c, '#9fd0ea', X + 30, Y + 34, 1, 5); c.globalAlpha = 1;
    }
  },
  tent(c, p) {
    const X = p.x * TILE, Y = p.y * TILE, col = TENT_COLORS[p.color] || '#e8743b';
    c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(X + 1, Y + 26, 30, 5);
    for (let i = 0; i < 14; i++) {
      R(c, col, X + 16 - i - 1, Y + 6 + i * 1.5, (i + 1) * 2, 2);
    }
    R(c, shade(col), X + 16, Y + 6, 1, 22);
    R(c, shade(col), X + 2, Y + 26, 28, 2);
    R(c, '#2a1d14', X + 13, Y + 18, 7, 10); R(c, col, X + 16, Y + 18, 1, 10);
    R(c, '#c9b99a', X, Y + 28, 1, 2); R(c, '#c9b99a', X + 31, Y + 28, 1, 2);
    R(c, '#5a3a22', X + 15, Y + 3, 2, 4);
  },
  boules(c, p) {
    const X = p.x * TILE, Y = p.y * TILE;
    R(c, '#9a9a92', X + 3, Y + 6, 3, 3); R(c, '#c0c0b8', X + 3, Y + 6, 1, 1);
    R(c, '#9a9a92', X + 10, Y + 9, 3, 3); R(c, '#c0c0b8', X + 10, Y + 9, 1, 1);
    R(c, '#e8743b', X + 7, Y + 4, 2, 2);
  },
  parasol(c, p, t) {
    const X = p.x * TILE, Y = p.y * TILE;
    c.fillStyle = 'rgba(0,0,0,.2)'; c.beginPath(); c.ellipse(X + 10, Y + 12, 9, 4, 0, 0, Math.PI * 2); c.fill();
    R(c, '#7d5430', X + 7, Y - 2, 2, 16);
    const cols = ['#e8743b', '#f6e7c8'];
    for (let i = 0; i < 6; i++) R(c, cols[i % 2], X - 4 + i * 4, Y - 8 + Math.abs(2.5 - i), 4, 6 - Math.abs(2.5 - i));
    R(c, '#2a1d14', X + 7, Y - 10, 2, 2);
  },
  clothesline(c, p, t) {
    const X = p.x * TILE, Y = p.y * TILE, w = p.w * TILE;
    R(c, '#5a3a22', X + 1, Y - 4, 2, 18); R(c, '#5a3a22', X + w - 3, Y - 4, 2, 18);
    R(c, '#2a1d14', X + 2, Y - 3, w - 4, 1);
    const sw = Math.round(Math.sin(t * 2) * 0.8);
    R(c, '#e8743b', X + 7 + sw, Y - 2, 6, 7); R(c, '#3d8fbf', X + 17 + sw, Y - 2, 8, 5); R(c, '#f3d36b', X + 30 + sw, Y - 2, 6, 8);
    R(c, '#c4472f', X + 39 + sw, Y - 2, 4, 4);
  },
  mns(c, p, t, ctx) {
    const X = p.x * TILE, Y = p.y * TILE;
    c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(X + 2, Y + 44, 30, 4);
    R(c, '#7d5430', X + 3, Y + 20, 3, 27); R(c, '#7d5430', X + 26, Y + 20, 3, 27);
    R(c, '#6b4a2a', X + 6, Y + 30, 20, 2); R(c, '#6b4a2a', X + 6, Y + 40, 20, 2);
    R(c, '#b98a55', X + 10, Y + 22, 2, 25); R(c, '#b98a55', X + 14, Y + 22, 2, 25);
    for (let i = 0; i < 6; i++) R(c, '#b98a55', X + 10, Y + 24 + i * 4, 6, 1);
    R(c, '#c4472f', X + 1, Y + 6, 30, 16); R(c, '#f4f1ea', X + 1, Y + 13, 30, 3);
    R(c, '#2b4e66', X + 5, Y + 8, 8, 4); R(c, '#2b4e66', X + 19, Y + 8, 8, 4);
    R(c, '#e7c98d', X - 1, Y + 2, 34, 5); R(c, '#c9a463', X - 1, Y + 6, 34, 1);
    text(c, 'MNS', X + 16, Y + 18.5, '#c4472f', 4);
    // Drapeau selon conditions
    const flag = { top: '#4caf50', ok: '#f2c230', avg: '#e8743b', night: '#6b7a99' }[ctx.cond.quality];
    R(c, '#2a1d14', X + 28, Y - 14, 1, 18);
    const fw = Math.round(Math.sin(t * 6) * 1);
    R(c, flag, X + 29, Y - 14, 9 + fw, 6);
  },
  board(c, p, t, ctx) {
    const X = p.x * TILE, Y = p.y * TILE;
    R(c, '#5a3a22', X + 3, Y + 8, 2, 7); R(c, '#5a3a22', X + 11, Y + 8, 2, 7);
    R(c, '#5a3a22', X, Y - 2, 16, 12); R(c, '#2a3a2e', X + 1, Y - 1, 14, 10);
    text(c, 'SURF', X + 8, Y + 2, '#f6e7c8', 3.4);
    const col = { top: '#4caf50', ok: '#f2c230', avg: '#e8743b', night: '#6b7a99' }[ctx.cond.quality];
    R(c, col, X + 5, Y + 5, 6, 2);
  },
  surfer(c, p, t) {
    const X = p.x * TILE, Y = p.y * TILE;
    const ph = (p.phase || 0) + t;
    const by = Math.round(Math.sin(ph * 1.6) * 1.5);
    const riding = Math.sin(ph * 0.35) > 0.85;
    const dx = riding ? Math.round((Math.sin(ph * 0.35) - 0.85) * 60) : 0;
    R(c, '#f4f1ea', X + 2 + dx, Y + 9 + by, 12, 3); R(c, '#e8743b', X + 2 + dx, Y + 10 + by, 12, 1);
    if (riding) {
      R(c, '#1f2a33', X + 6 + dx, Y + 1 + by, 3, 8); R(c, '#c98d5e', X + 6 + dx, Y - 2 + by, 3, 3);
      R(c, '#1f2a33', X + 3 + dx, Y + 3 + by, 9, 1);
      R(c, '#f4f8f6', X + dx - 2, Y + 11 + by, 4, 2);
    } else {
      R(c, '#1f2a33', X + 5, Y + 6 + by, 5, 4); R(c, '#c98d5e', X + 6, Y + 3 + by, 3, 3);
    }
  },
  sandboard(c, p) {
    const X = p.x * TILE, Y = p.y * TILE;
    c.fillStyle = 'rgba(0,0,0,.18)'; c.fillRect(X + 8, Y + 12, 8, 3);
    R(c, '#f3a648', X + 5, Y - 10, 6, 24); R(c, '#f4f1ea', X + 7, Y - 10, 2, 24); R(c, '#f3a648', X + 6, Y - 12, 4, 2);
  },
  towel(c, p) {
    const X = p.x * TILE, Y = p.y * TILE;
    for (let i = 0; i < 4; i++) R(c, i % 2 ? '#f6e7c8' : '#3d8fbf', X - 1 + i * 5, Y + 3, 5, 10);
  },
  oyat(c, p, t) {
    const X = p.x * TILE, Y = p.y * TILE;
    const s = Math.round(Math.sin(t * 1.5 + p.x) * 1);
    for (let i = 0; i < 5; i++) R(c, i % 2 ? '#9aa35a' : '#b8b46a', X + 3 + i * 2 + s, Y + 4 + (i % 3), 1, 9 - (i % 3));
  },
  barsign(c, p) {
    const X = p.x * TILE, Y = p.y * TILE, w = p.w * TILE;
    R(c, '#2a1d14', X + 2, Y + 1, w - 4, 13); R(c, '#1d5f8a', X + 3, Y + 2, w - 6, 11);
    text(c, 'LE SWELL', X + w / 2, Y + 8, '#f3d36b', 6);
  },
  terrace_table(c, p, t) {
    PROPS.table(c, p);
    PROPS.parasol(c, { x: p.x, y: p.y - 0.6 }, t);
  },
  shelf(c, p) {
    const X = p.x * TILE, Y = p.y * TILE, w = p.w * TILE;
    R(c, '#6e4524', X, Y + 2, w, 13);
    R(c, '#8a5a2f', X, Y + 7, w, 2); R(c, '#8a5a2f', X, Y + 13, w, 2);
    const cols = ['#4f8a5b', '#c4472f', '#f3d36b', '#3d8fbf', '#f4f1ea', '#7a5a9a'];
    for (let i = 0; i < w / 4 - 1; i++) {
      R(c, cols[i % cols.length], X + 2 + i * 4, Y + 2, 2, 5); R(c, cols[(i + 2) % cols.length], X + 2 + i * 4, Y + 9, 2, 4);
    }
  },
  counter(c, p) {
    const X = p.x * TILE, Y = p.y * TILE, w = p.w * TILE;
    c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(X, Y + 14, w, 3);
    R(c, '#6e4524', X, Y + 4, w, 12);
    for (let i = 0; i < w; i += 8) R(c, '#5a3a1e', X + i, Y + 6, 1, 10);
    R(c, '#c99a63', X - 1, Y + 1, w + 2, 4);
    R(c, '#c0c0b8', X + 40, Y - 5, 2, 7); R(c, '#e8743b', X + 39, Y - 6, 4, 2);
    R(c, '#f3d36b', X + 20, Y - 2, 3, 4); R(c, '#f4f1ea', X + 20, Y - 3, 3, 1);
  },
  jukebox(c, p, t) {
    const X = p.x * TILE, Y = p.y * TILE;
    R(c, '#c4472f', X + 2, Y - 4, 12, 19); R(c, '#f3d36b', X + 3, Y - 3, 10, 6);
    const hue = Math.floor(t * 3) % 3;
    R(c, ['#7fd18b', '#9fd0ea', '#f3a648'][hue], X + 4, Y + 5, 8, 4);
    R(c, '#2a1d14', X + 5, Y + 11, 6, 2);
  },
  stage(c, p, t) {
    const X = p.x * TILE, Y = p.y * TILE, w = p.w * TILE, h = p.h * TILE;
    R(c, '#5a3a1e', X, Y + 4, w, h - 4);
    for (let i = 0; i < h - 8; i += 5) R(c, '#6e4524', X, Y + 6 + i, w, 1);
    R(c, '#2a1d14', X, Y + h - 6, w, 6); R(c, '#8a5a2f', X, Y + 4, w, 2);
    // Guirlande
    for (let i = 0; i < w; i += 8) {
      const on = (Math.floor(t * 2) + i / 8) % 2 === 0;
      R(c, '#2a1d14', X + i, Y - 2, 8, 1);
      R(c, on ? ['#f3d36b', '#e8743b', '#7fd18b', '#9fd0ea'][(i / 8) % 4] : '#5a4a3a', X + i + 3, Y - 1, 2, 2);
    }
    // Ampli, micro, guitare
    R(c, '#2a2a2a', X + 4, Y + 10, 14, 12); R(c, '#555', X + 6, Y + 12, 10, 8); R(c, '#f3d36b', X + 7, Y + 20, 2, 1);
    R(c, '#9a9a92', X + 46, Y + 8, 1, 16); R(c, '#2a1d14', X + 45, Y + 6, 3, 3);
    R(c, '#c47a2f', X + 66, Y + 16, 12, 9); R(c, '#e8a04b', X + 67, Y + 17, 10, 7); R(c, '#2a1d14', X + 71, Y + 19, 3, 3);
    R(c, '#6e4524', X + 70, Y + 2, 3, 15); R(c, '#2a1d14', X + 69, Y, 5, 3);
  },
};
