// Moteur : déplacement case par case, collisions, sorties de carte, interactions, et l'API `g`
// passée aux scripts de PNJ/événements (data/*.js).
import { MAPS, TILE, SOLID_TERRAIN, travelTime } from '../data/maps.js';
import { NPCS, LOOKS } from '../data/npcs.js';
import { QUESTS, currentObjective } from '../data/quests.js';
import { ACTIONS, EVENTS } from '../data/events.js';
import { conditionsAt, SPOTS } from '../data/surf.js';
import { advanceClock, wakeUp, applyDeltas, save, fmtTime } from '../state.js';
import { Renderer } from './render.js';
import { ui } from '../ui/ui.js';
import { minigame } from '../ui/minigame.js';
import { bushBattle } from '../ui/bushBattle.js';
import { pickBushEnemy } from '../data/bushes.js';

const DIRS = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] };
const OPP = { up: 'down', down: 'up', left: 'right', right: 'left' };
const STEP_TIME = 0.18;   // secondes par case
const TURN_DELAY = 0.08;  // un tap court tourne le perso sans avancer

const fmtDuration = m => (m >= 60 ? `${Math.floor(m / 60)} h${m % 60 ? ' ' + String(m % 60).padStart(2, '0') : ''}` : `${m} min`);

export class Game {
  constructor(canvas, input) {
    this.renderer = new Renderer(canvas);
    this.input = input;
    this.busy = 0;
    this.temps = [];
    this.target = null;
    this.npcFacing = {};
    this.running = false;
    this.api = this.makeApi();
    this._loop = this.loop.bind(this);
    window.addEventListener('resize', () => this.renderer.resize());
  }

  get map() { return MAPS[this.s.map]; }

  start(state, isNew) {
    this.s = state;
    this.temps = [];
    this.busy = 0;
    this.player = { x: 0, y: 0, px: 0, py: 0, facing: 'down', look: LOOKS.player, moving: false, frame: 0, walkT: 0, turnT: 0, wasMoving: false };
    if (!MAPS[state.map]) state.map = 'parking';
    this.place(state.map, state.x, state.y, state.facing || 'down');
    this.lastPrompt = undefined;
    this.refreshHud();
    save(this.s);
    requestAnimationFrame(() => this.renderer.resize());
    if (!this.running) { this.running = true; this.last = performance.now(); requestAnimationFrame(this._loop); }
    if (isNew) this.run(() => EVENTS.intro.run(this.api));
  }

  stop() { this.running = false; }

  loop(ts) {
    if (!this.running) return;
    const dt = Math.min(0.05, (ts - this.last) / 1000);
    this.last = ts;
    this.update(dt);
    this.renderer.draw(this, ts / 1000);
    requestAnimationFrame(this._loop);
  }

  // ------------------------------------------------------------ MONDE
  npcs() {
    const s = this.s, list = [];
    for (const [id, n] of Object.entries(NPCS)) {
      if (n.map !== s.map || (n.visible && !n.visible(s))) continue;
      list.push({ id, name: n.name, x: n.x, y: n.y, px: n.x * TILE, py: n.y * TILE, look: n.look, facing: this.npcFacing[id] || n.facing, emote: n.emote ? n.emote(s) : null });
    }
    for (const t of this.temps) list.push({ ...t, px: t.x * TILE, py: t.y * TILE, look: typeof t.look === 'string' ? LOOKS[t.look] : t.look, temp: true });
    return list;
  }
  visibleNpcs() { return this.npcs(); }

  propsAt(x, y) {
    return this.map.props.filter(p => x >= p.x && x < p.x + (p.w || 1) && y >= p.y && y < p.y + (p.h || 1));
  }

  blocked(x, y) {
    const m = this.map;
    if (x < 0 || y < 0 || x >= m.w || y >= m.h) return true;
    if (SOLID_TERRAIN.has(m.tiles[y][x])) return true;
    if (this.propsAt(x, y).some(p => p.solid !== false)) return true;
    return this.npcs().some(n => n.x === x && n.y === y);
  }

  /** Case libre la plus proche (sécurité anti-blocage après une téléportation). */
  findFree(x, y) {
    const seen = new Set([`${x},${y}`]);
    const q = [[x, y]];
    while (q.length) {
      const [cx, cy] = q.shift();
      if (!this.blocked(cx, cy) && !this.exitAt(cx, cy)) return [cx, cy];
      for (const [dx, dy] of Object.values(DIRS)) {
        const k = `${cx + dx},${cy + dy}`;
        if (seen.has(k) || cx + dx < 0 || cy + dy < 0 || cx + dx >= this.map.w || cy + dy >= this.map.h) continue;
        seen.add(k); q.push([cx + dx, cy + dy]);
      }
    }
    return [x, y];
  }

  exitAt(x, y) {
    return this.map.exits.find(e => x >= e.x && x < e.x + e.w && y >= e.y && y < e.y + e.h);
  }

  place(mapId, x, y, facing) {
    if (this.s.map !== mapId) this.npcFacing = {};
    this.s.map = mapId;
    if (this.blocked(x, y)) [x, y] = this.findFree(x, y);
    const p = this.player;
    Object.assign(p, { x, y, px: x * TILE, py: y * TILE, moving: false, frame: 0, turnT: 0, wasMoving: false });
    if (facing) p.facing = facing;
    Object.assign(this.s, { x, y, facing: p.facing });
    this.target = null;
  }

  // ------------------------------------------------------------ BOUCLE
  update(dt) {
    const p = this.player;
    if (p.moving) {
      p.prog = Math.min(1, p.prog + dt / STEP_TIME);
      p.px = (p.fx + (p.tx - p.fx) * p.prog) * TILE;
      p.py = (p.fy + (p.ty - p.fy) * p.prog) * TILE;
      p.walkT += dt;
      p.frame = Math.floor(p.walkT * 9) % 4;
      if (p.prog >= 1) {
        p.moving = false;
        p.x = p.tx; p.y = p.ty;
        this.onArrive();
      }
    }
    if (!p.moving && !this.busy && !ui.menuOpen && !ui.dialogActive && !minigame.active) {
      const d = this.input.dir();
      if (d) {
        if (d !== p.facing) {
          p.facing = d;
          if (!p.wasMoving) p.turnT = TURN_DELAY;
        }
        if (p.turnT > 0) p.turnT -= dt;
        else this.tryMove(d);
      } else {
        p.frame = 0; p.wasMoving = false; p.turnT = 0;
      }
    } else if (!p.moving) p.frame = 0;

    const tg = (!p.moving && !this.busy) ? this.findTarget() : null;
    this.target = tg;
    const label = this.busy ? null : (tg ? tg.label : null);
    if (label !== this.lastPrompt) { this.lastPrompt = label; ui.prompt(label); }
  }

  tryMove(d) {
    const p = this.player;
    const [dx, dy] = DIRS[d];
    const nx = p.x + dx, ny = p.y + dy;
    if (this.blocked(nx, ny)) { p.wasMoving = false; p.frame = 0; return; }
    Object.assign(p, { moving: true, fx: p.x, fy: p.y, tx: nx, ty: ny, prog: 0, wasMoving: true });
  }

  onArrive() {
    const p = this.player;
    Object.assign(this.s, { x: p.x, y: p.y, facing: p.facing });
    const exit = this.exitAt(p.x, p.y);
    if (exit) { this.run(() => this.changeMap(exit)); return; }
    if (this.s.map === 'buissons' && this.map.tiles[p.y]?.[p.x] === 'x') {
      const safe = this.s.flags.bushSafeSteps || 0;
      if (safe > 0) this.s.flags.bushSafeSteps = safe - 1;
      else if (Math.random() < 0.28) {
        this.s.flags.bushSafeSteps = 3;
        this.run(() => this.bushEncounter());
        return;
      }
    }
    save(this.s);
  }

  async bushEncounter() {
    const s = this.s;
    const enemy = pickBushEnemy();
    s.stats.bushEncounters = (s.stats.bushEncounters || 0) + 1;
    const hasBotte = !!s.flags.roiForet;
    const res = await bushBattle.run(enemy, { revealFirst: hasBotte, fleeBonus: hasBotte });
    if (res.minutes) this.api.time(res.minutes);
    if (res.stoke || res.legend) this.api.gain({ stoke: res.stoke || 0, legend: res.legend || 0 });
    if (res.result === 'win') {
      s.stats.bushWins = (s.stats.bushWins || 0) + 1;
      this.api.toast(`Roi de la forêt : ${Math.min(3, s.stats.bushWins)} / 3`, 'good');
      if (s.stats.bushWins >= 3 && !s.flags.roiForet) {
        s.flags.roiForet = true;
        await this.api.say('', 'BOTTE DÉBLOQUÉE — ROI DE LA FORÊT
Tu lis mieux les Buissonneurs et tu fuis plus facilement.');
      }
    }
    save(s);
  }

  async changeMap(exit) {
    const s = this.s, p = this.player;
    const from = s.map, to = exit.to;
    const dest = MAPS[to];
    const idx = exit.w > 1 ? p.x - exit.x : p.y - exit.y;
    const mins = travelTime(from, to);
    await ui.fade(`${dest.name}\n+${fmtDuration(mins)} de trajet`, 450, async () => {
      advanceClock(s, mins);
      const back = dest.exits.find(e => e.to === from);
      if (back) {
        const len = Math.max(back.w, back.h);
        const i = Math.min(Math.max(idx, 0), len - 1);
        const inward = OPP[back.dir];
        const x = back.x + (back.w > 1 ? i : 0) + DIRS[inward][0];
        const y = back.y + (back.h > 1 ? i : 0) + DIRS[inward][1];
        this.place(to, x, y, inward);
      } else {
        this.place(to, Math.floor(dest.w / 2), Math.floor(dest.h / 2), 'down');
      }
      this.refreshHud();
    });
    ui.toast(`${dest.name} · +${fmtDuration(mins)}`, 'time');
    save(s);
    if (to === 'plage' && !s.flags.seenBeach) { s.flags.seenBeach = true; await EVENTS.firstBeach.run(this.api); }
  }

  // ------------------------------------------------------------ INTERACTIONS
  targetAt(x, y) {
    const m = this.map;
    const n = this.npcs().find(n => n.x === x && n.y === y && !n.temp);
    if (n) return { kind: 'npc', id: n.id, label: n.name, tx: x, ty: y };
    const pr = this.propsAt(x, y).find(p => p.interact);
    if (pr) {
      if (pr.interact.startsWith('npc:')) {
        const id = pr.interact.slice(4);
        return { kind: 'npc', id, label: pr.label || NPCS[id].name, tx: x, ty: y };
      }
      return { kind: 'prop', prop: pr, label: pr.label || (pr.type === 'sign' ? `Panneau ${pr.text}` : pr.type), tx: x, ty: y };
    }
    if (m.beach && m.tiles[y]?.[x] === 'w') return { kind: 'surf', label: 'Surfer (océan)', tx: x, ty: y };
    return null;
  }

  findTarget() {
    const p = this.player;
    const [dx, dy] = DIRS[p.facing];
    const front = this.targetAt(p.x + dx, p.y + dy);
    if (front) return { ...front, dir: p.facing };
    // Tolérance mobile : un PNJ juste à côté reste interactif même si on ne lui fait pas face
    for (const [d, [ax, ay]] of Object.entries(DIRS)) {
      if (d === p.facing) continue;
      const t = this.targetAt(p.x + ax, p.y + ay);
      if (t && t.kind === 'npc') return { ...t, dir: d };
    }
    return null;
  }

  interact() {
    if (this.busy || ui.menuOpen || this.player.moving) return;
    const t = this.target || this.findTarget();
    if (!t) { ui.toast('Rien à faire ici. Approche-toi de quelqu’un ou de quelque chose.'); return; }
    const p = this.player;
    p.facing = t.dir || p.facing;
    if (t.kind === 'npc') {
      this.npcFacing[t.id] = OPP[p.facing];
      this.run(() => NPCS[t.id].talk(this.api));
    } else if (t.kind === 'prop') {
      this.run(() => ACTIONS[t.prop.interact](this.api, t.prop));
    } else if (t.kind === 'surf') {
      this.run(() => ACTIONS.surf(this.api));
    }
  }

  async run(fn) {
    this.busy++;
    ui.prompt(null); this.lastPrompt = null;
    try { await fn(); } catch (e) { console.error(e); }
    finally {
      this.busy = Math.max(0, this.busy - 1);
      this.refreshHud();
      save(this.s);
    }
  }

  conditions() { return conditionsAt(this.s.time); }

  refreshHud() {
    const m = this.map;
    ui.hud(this.s, m.name, m.beach ? this.conditions() : null, currentObjective(this.s));
  }

  // ------------------------------------------------------------ MENU
  menuHtml() {
    const s = this.s;
    const qs = Object.entries(QUESTS).map(([id, q]) => {
      const st = s.quests[id];
      if (!st) return '';
      return `<li><b>${q.title}</b> — ${q.objectives[st]}</li>`;
    }).join('') || '<li>Aucune quête pour l’instant. Parle aux gens…</li>';
    const rel = Object.entries(s.relations).map(([id, v]) => `${NPCS[id]?.name || id} ${'♥'.repeat(Math.min(5, v)) || '·'}`).join(' · ');
    const cond = this.conditions();
    const wins = SPOTS.casernas.windows.map(w => `<li>${fmtTime(w.from)}–${fmtTime(w.to)} : ${w.label}</li>`).join('');
    return `
      <p>Jour ${s.day}, ${fmtTime(s.time)} · ${s.money} € · Stoke ${s.stoke} · Légende ${s.legend}</p>
      <h3>Quêtes</h3><ul>${qs}</ul>
      <h3>Surf (d'après l'Ancien)</h3><p>Maintenant : <b>${cond.label}</b></p><ul>${wins}<li>Le reste du temps : Moyennes</li></ul>
      <h3>Buissons</h3><p>Victoires : ${s.stats.bushWins || 0} · Rencontres : ${s.stats.bushEncounters || 0}${s.flags.roiForet ? ' · <b>Botte ROI DE LA FORÊT débloquée</b>' : ' · Botte : ' + Math.min(3, s.stats.bushWins || 0) + '/3'}</p>
      <h3>Relations</h3><p>${rel}</p>
      <h3>Carnet</h3><p>Sessions de surf : ${s.stats.surfSessions} · Vagues surfées : ${s.stats.wavesRidden} · Concerts : ${s.stats.gigs}<br>Nuits au camping : ${s.stats.nightsCamping} · Nuits dans le van : ${s.stats.nightsVan}</p>
      <h3>Astuces</h3><p>Plus tu as de Stoke, plus la zone de take-off est large. Camping = cher mais sûr. Parking = gratuit mais risqué.</p>
      <h3>Contrôles</h3><p>Croix ou flèches/ZQSD pour marcher, INTERAGIR ou Espace pour parler/agir, Échap pour ce carnet. La partie se sauvegarde toute seule.</p>`;
  }

  // ------------------------------------------------------------ API des scripts
  makeApi() {
    const game = this;
    const api = {
      get s() { return game.s; },
      get map() { return game.map; },
      say: (speaker, text) => ui.say(speaker, text),
      ask: (speaker, text, choices) => ui.say(speaker, text, choices),
      toast: (text, kind) => ui.toast(text, kind),
      time(min) {
        if (!(min > 0)) return;
        advanceClock(game.s, min);
        ui.toast(`+${fmtDuration(min)} → ${fmtTime(game.s.time)}`, 'time');
        game.refreshHud(); save(game.s);
      },
      gain(d) {
        const out = applyDeltas(game.s, d);
        if (out.money) ui.toast(`${out.money > 0 ? '+' : ''}${out.money} €`, out.money > 0 ? 'good' : 'bad');
        if (out.stoke) ui.toast(`${out.stoke > 0 ? '+' : ''}${out.stoke} Stoke`, out.stoke > 0 ? 'good' : 'bad');
        if (out.legend) ui.toast(`${out.legend > 0 ? '+' : ''}${out.legend} Légende ★`, out.legend > 0 ? 'good' : 'bad');
        game.refreshHud(); save(game.s);
        return out;
      },
      pay(n) {
        if (game.s.money < n) { ui.toast(`Pas assez d'argent (${n} €)`, 'bad'); return false; }
        game.s.money -= n;
        ui.toast(`-${n} €`, 'bad');
        game.refreshHud(); save(game.s);
        return true;
      },
      setQuest(id, st) {
        const prev = game.s.quests[id];
        game.s.quests[id] = st;
        const q = QUESTS[id];
        if (st === 'active' && prev !== 'active') ui.toast(`Nouvelle quête : ${q.title}`, 'good');
        if (st === 'done') ui.toast(`Quête terminée : ${q.title}`, 'good');
        game.refreshHud(); save(game.s);
      },
      rel(id, n) { game.s.relations[id] = (game.s.relations[id] || 0) + n; },
      fade: (text, ms, mid) => ui.fade(text, ms, mid),
      minigame: o => minigame.run(o),
      bushBattle: (enemy, opts) => bushBattle.run(enemy, opts),
      action: id => ACTIONS[id](api),
      gig: () => ACTIONS.gig(api),
      wakeUp() { wakeUp(game.s); game.refreshHud(); },
      teleport(mapId, spot) {
        const sp = typeof spot === 'string' ? MAPS[mapId][spot] : spot;
        game.place(mapId, sp.x, sp.y, sp.facing);
        game.refreshHud(); save(game.s);
      },
      spawnTemp(n) { game.temps.push(n); },
      removeTemp(id) { game.temps = game.temps.filter(t => t.id !== id); },
    };
    return api;
  }
}
