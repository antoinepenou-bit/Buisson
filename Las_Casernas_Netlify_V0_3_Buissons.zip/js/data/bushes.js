// Rencontres des Buissons : confrontations sociales absurdes à patterns.
// Le joueur apprend les enchaînements : une bonne réponse baisse l'Insistance,
// une mauvaise réponse baisse le Sang-froid. Fuir reste toujours possible.

export const BUSH_ENEMIES = {
  parasol: {
    id: 'parasol', name: 'Buissonneur à parasol', rarity: 4,
    intro: 'Un parasol surgit entre deux ajoncs. Son propriétaire te fixe comme si TU étais sur SON passage.',
    color: '#e3a344', accent: '#f7e29b',
    pattern: [
      { attack: 'PARASOL TOURNANT', line: 'Il déploie son parasol dans l’unique passage.', best: 'esquiver', hint: 'Le passage se ferme. Mieux vaut bouger que discuter.' },
      { attack: 'QUESTION GÊNANTE', line: '« Et sinon, tu fais quoi dans la vie ? »', best: 'bluffer', hint: 'Il attend une réponse. Une réponse trop vraie serait une erreur.' },
      { attack: 'BARRAGE DE CHEMIN', line: 'Il s’installe exactement là où tu veux passer.', best: 'repliquer', hint: 'Il teste si tu vas céder le terrain.' },
    ],
  },
  bluecap: {
    id: 'bluecap', name: 'Buissonneur casquette bleue', rarity: 4,
    intro: 'Un short, une casquette bleue, beaucoup trop d’énergie : il bondit hors du sentier.',
    color: '#3b73b9', accent: '#7db7ef',
    pattern: [
      { attack: '« EH MEC ! »', line: 'Il attaque avec un « EH MEC ! » lancé à pleine puissance.', best: 'ignorer', hint: 'Réagir, c’est déjà lui donner ce qu’il veut.' },
      { attack: 'SPRINT LATÉRAL', line: 'Il change brutalement de côté pour te couper la route.', best: 'esquiver', hint: 'Ses pieds parlent plus vite que sa bouche.' },
      { attack: 'FAUSSE DIRECTION', line: '« La plage ? C’est par là, frère. » Il pointe manifestement vers la forêt.', best: 'bluffer', hint: 'Fais comme si tu savais exactement où tu vas.' },
    ],
  },
  couple: {
    id: 'couple', name: 'Couple de Buissonneurs', rarity: 3,
    intro: 'Un couple te repère. Ils se concertent une demi-seconde : tu sais déjà que ça va être long.',
    color: '#c85f65', accent: '#f2b7a0', duo: true,
    pattern: [
      { attack: 'DOUBLE INTERROGATION', line: '« Vous êtes d’où ? » / « Et vous restez combien de temps ? »', best: 'bluffer', hint: 'Deux questions. Une seule fausse réponse peut suffire.' },
      { attack: 'ENCERCLEMENT SOCIAL', line: 'Ils se placent chacun d’un côté du sentier, très cordialement.', best: 'esquiver', hint: 'Ce n’est pas agressif. C’est pire : c’est organisé.' },
      { attack: 'DIVERSION DE COUPLE', line: 'Ils commencent une dispute absurde sur la meilleure boulangerie.', best: 'ignorer', hint: 'Ne choisis surtout pas un camp.' },
    ],
  },
  chief: {
    id: 'chief', name: 'Chef des Buissonneurs', rarity: 1,
    intro: 'Longue barbe, lunettes de soleil, immobilité totale. Le sentier lui appartient depuis avant ta naissance.',
    color: '#59634a', accent: '#d2b071', chief: true,
    pattern: [
      { attack: 'REGARD DU PATRIARCHE', line: 'Il ne dit rien. Il te regarde. Le silence devient administratif.', best: 'ignorer', hint: 'Le premier qui parle a perdu quelque chose.' },
      { attack: 'MONOLOGUE SANS FIN', line: '« En 1998, ici, tu vois, c’était pas pareil… »', best: 'esquiver', hint: 'La fenêtre de fuite se mesure en millisecondes.' },
      { attack: 'APPEL DU CLAN', line: 'Un sifflement. Des feuilles bougent autour de vous.', best: 'repliquer', hint: 'Il faut reprendre l’initiative avant que le public arrive.' },
      { attack: 'SENTENCE DU BUISSON', line: '« Bon. On va faire simple. » Il croise les bras.', best: 'bluffer', hint: 'Rien n’est simple. Fais semblant que si.' },
    ],
  },
};

export const BUSH_ACTIONS = [
  { id: 'ignorer', label: 'IGNORER', sub: 'Ne rien nourrir.' },
  { id: 'bluffer', label: 'BLUFFER', sub: 'Inventer avec aplomb.' },
  { id: 'esquiver', label: 'ESQUIVER', sub: 'Bouger avant la suite.' },
  { id: 'repliquer', label: 'RÉPLIQUER', sub: 'Reprendre l’initiative.' },
];

export function pickBushEnemy() {
  const pool = [];
  for (const e of Object.values(BUSH_ENEMIES)) for (let i = 0; i < e.rarity; i++) pool.push(e);
  return pool[Math.floor(Math.random() * pool.length)];
}
