// Actions sur les objets du décor + événements scénarisés.
// Un prop avec `interact: 'cafe'` appelle ACTIONS.cafe(g). Pour un nouvel objet : une entrée ici.
import { conditionsAt, SPOTS, SURF_REWARDS, SURF_SESSION_MIN } from './surf.js';
import { fmtTime } from '../state.js';
import { sceneIsOpen, eveningOf } from './npcs.js';

const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const DAYTIME = t => t >= 9 * 60 && t < 17 * 60;

export const ACTIONS = {
  async sign(g, prop) {
    await g.say('', `Panneau : ${prop.text} ${({ up: '↑', down: '↓', left: '←', right: '→' })[prop.arrow] || ''}`);
  },

  async cafe(g) {
    const c = await g.ask('Momo', "Un p'tit noir ? 2 €. Du vrai, pas du café de station-service.", [
      { label: 'Un café', sub: '2 € · 15 min · +1 Stoke (1er du jour)' },
      { label: 'Non merci' },
    ]);
    if (c !== 0) return;
    if (!g.pay(2)) return g.say('Momo', "Pas de sous, pas de café. Mais je te souris gratuitement. Voilà.");
    g.time(15);
    if (!g.s.daily.cafe) {
      g.s.daily.cafe = true;
      g.gain({ stoke: 1 });
      await g.say('Momo', pick(["Et voilà. Ça réveille même les mouettes.", "Serré, comme le parking en août."]));
    } else {
      await g.say('Momo', "Encore un ? Ton œil gauche tremble. Pas de Stoke en plus, juste des palpitations.");
    }
  },

  async shower(g) {
    const c = await g.ask('', 'Sanitaires du camping. Douche chaude au jeton.', [
      { label: 'Prendre une douche', sub: '3 € · 20 min · +1 Stoke' },
      { label: 'Plus tard' },
    ]);
    if (c !== 0) return;
    if (!g.pay(3)) return g.say('', "Pas assez pour un jeton. L'océan, lui, est gratuit. Et froid.");
    g.time(20);
    g.gain({ stoke: 1 });
    await g.say('', pick([
      "L'eau est chaude pendant 40 secondes. Ce sont les 40 meilleures secondes de ta semaine.",
      "Tu chantes sous la douche. Quelqu'un dans la cabine d'à côté reprend le refrain.",
    ]));
  },

  async accueil(g) {
    const c = await g.ask('Accueil', 'Une nuit au camping : emplacement, douche du matin, zéro contrôle.', [
      { label: 'Dormir ici', sub: '12 € · réveil 07:00 · +2 Stoke · sûr' },
      { label: 'Non merci' },
    ]);
    if (c !== 0) return;
    if (g.s.money < 12) return g.say('Accueil', "Il manque des sous. Le parking est gratuit… à tes risques.");
    if (!(await confirmEarly(g))) return;
    g.pay(12);
    await sleep(g, 'camping');
  },

  async myvan(g) {
    const c = await g.ask('', 'Ton van. Il sent la wax et la chaussette mouillée.', [
      { label: 'Dormir dans le van', sub: 'Gratuit · réveil 07:00 · +1 Stoke · risqué' },
      { label: 'Laisser tomber' },
    ]);
    if (c !== 0) return;
    if (!(await confirmEarly(g))) return;
    await sleep(g, 'van');
  },

  async board(g) {
    const cond = conditionsAt(g.s.time);
    const rows = SPOTS.casernas.windows.map(w => `${fmtTime(w.from)}–${fmtTime(w.to)} : ${w.label}`).join('\n');
    await g.say('Tableau MNS', `Maintenant (${fmtTime(g.s.time)}) : ${cond.label.toUpperCase()}\n${rows}\nLe reste du temps : Moyennes.`);
  },

  async counter(g) {
    const c = await g.ask('Fred', "Qu'est-ce que je te sers ? La cuisine est ouverte tant que le cuistot est réveillé.", [
      { label: 'Assiette de frites landaises', sub: '6 € · repas · 30 min · +1 Stoke' },
      { label: 'Juste un verre d\'eau', sub: 'Gratuit · 5 min' },
      { label: 'Rien' },
    ]);
    if (c === 0) {
      if (!g.pay(6)) return g.say('Fred', "Six euros, chef. Les frites, c'est pas du bénévolat.");
      g.time(30);
      g.gain({ stoke: 1 });
      await g.say('Fred', "Frites maison, graisse de canard. Si tu surfes après, tu flottes mieux.");
    } else if (c === 1) {
      g.time(5);
      await g.say('Fred', "De l'eau. Bon. Je mets ça sur ton compte « déceptions ».");
    }
  },

  async stage(g) { return ACTIONS.gig(g); },

  // ------------------------------- SURF -------------------------------
  async surf(g) {
    const cond = conditionsAt(g.s.time);
    if (cond.quality === 'night') {
      return g.say('', "Il fait nuit noire. Même toi, t'es pas assez fou. Reviens au lever du jour.");
    }
    const c = await g.ask('', `L'océan t'appelle.\nConditions : ${cond.label.toUpperCase()} — ${cond.note}`, [
      { label: "À l'eau !", sub: `Session de ${SURF_SESSION_MIN} min` },
      { label: 'Pas maintenant' },
    ]);
    if (c !== 0) return;
    const quality = cond.quality;
    const zone = Math.min(0.38, Math.max(0.14, 0.15 + g.s.stoke * 0.016 + (quality === 'top' ? 0.03 : quality === 'avg' ? -0.02 : 0)));
    const res = await g.minigame({
      theme: 'surf', quality,
      kicker: `Conditions ${cond.label.toLowerCase()} · Stoke ${g.s.stoke}`,
      title: 'Une série arrive !',
      button: 'TAKE-OFF',
      rounds: 1, need: 1, zone, sweep: quality === 'top' ? 1.05 : 0.95,
      hint: 'Appuie sur TAKE-OFF quand le curseur est dans la zone verte.',
    });
    g.time(SURF_SESSION_MIN);
    g.s.stats.surfSessions += 1;
    if (res.success) {
      g.s.stats.wavesRidden += 1;
      g.gain(SURF_REWARDS[quality]);
      await g.say('', pick({
        top: ["Take-off parfait. La vague déroule, tu glisses jusqu'au bord. Sur la plage, quelqu'un applaudit. C'est peut-être Patrick.", "Une gauche longue comme un dimanche. Tu ressors avec un sourire qui ne tient plus sur ton visage."],
        ok: ["Belle vague. Pas la vague de ta vie, mais une vague de ta semaine."],
        avg: ["C'était clapoteux, mais tu as tenu debout. Ça compte. Un peu."],
      }[quality]));
    } else {
      g.gain(SURF_REWARDS.fail);
      await g.say('', pick([
        "Tu pars trop tard. La vague te lave comme un vieux t-shirt. Tu ressors avec du sable dans des endroits insoupçonnés.",
        "Tu te lèves… et la planche continue sans toi. Elle a l'air heureuse, elle.",
      ]));
    }
  },

  // -------------------------- SCÈNE OUVERTE ---------------------------
  async gig(g) {
    const s = g.s;
    if (!sceneIsOpen(s.time)) return g.say('Lina', `La scène ouvre à 18:00. En attendant, tu peux accorder ta guitare. Ou ton âme.`);
    if (s.flags.gigDay === eveningOf(s)) return g.say('Lina', "Un seul passage par soirée, star. Laisse une chance aux autres.");
    const c = await g.ask('Lina', "Trois morceaux, trois accords. Il faut en réussir au moins deux. Prêt ?", [
      { label: 'Monter sur scène', sub: '45 min · réussite : +2 Légende +2 Stoke' },
      { label: 'Finalement non' },
    ]);
    if (c !== 0) return;
    s.flags.gigDay = eveningOf(s);
    const res = await g.minigame({
      theme: 'gig',
      kicker: 'Scène ouverte du Swell',
      title: '« Las Casernas Blues »',
      button: 'GRATTER !',
      rounds: 3, need: 2,
      zone: Math.min(0.3, 0.17 + s.stoke * 0.01), sweep: [0.95, 0.85, 0.75],
      hint: 'Frappe l’accord quand le curseur est dans la zone verte. 2 sur 3 pour réussir.',
    });
    g.time(45);
    s.stats.gigs += 1;
    if (res.success) {
      g.gain({ legend: 2, stoke: 2 });
      g.rel('lina', 1);
      await g.say('Lina', "Ouaaais ! La salle chante avec toi. Même Fred a lâché son torchon.");
    } else {
      g.gain({ stoke: -1 });
      await g.say('Lina', "Bon… c'était courageux. Le chien de Bixente a hurlé, mais je crois que c'était de l'émotion.");
    }
  },
};

/** Avertit si on va dormir en plein jour (on se réveille quand même le lendemain 07:00). */
async function confirmEarly(g) {
  if (!DAYTIME(g.s.time)) return true;
  const c = await g.ask('', `Il est ${fmtTime(g.s.time)}, il fait grand jour. Dormir maintenant, c'est sauter le reste de la journée jusqu'à demain 07:00.`, [
    { label: 'Dodo quand même' }, { label: 'Non, je profite' },
  ]);
  return c === 0;
}

/** Sommeil : camping (cher, sûr) ou van sur le parking (gratuit, risqué). */
export async function sleep(g, where) {
  const s = g.s;
  if (where === 'camping') {
    await g.fade('Zzz…\nNuit calme au camping.\nGérard le matelas veille sur toi.', 1500, async () => {
      g.wakeUp();
      g.teleport('camping', 'sleepSpot');
    });
    s.stats.nightsCamping += 1;
    g.gain({ stoke: 2 });
    g.toast(`Jour ${s.day} — 07:00`, 'time');
    await g.say('', 'Tu te réveilles reposé. Dehors, les pins sentent la résine et le café.');
    return;
  }
  await g.fade('Zzz…\nNuit dans le van.\nUn moustique t\'a adopté.', 1500, async () => {
    g.wakeUp();
    g.teleport('parking', 'sleepSpot');
  });
  s.stats.nightsVan += 1;
  g.gain({ stoke: 1 });
  g.toast(`Jour ${s.day} — 07:00`, 'time');
  if (Math.random() < EVENTS.morningControl.chance) await EVENTS.morningControl.run(g);
  else await g.say('', "Personne n'a toqué. Nuit gratuite, conscience presque tranquille.");
}

export const EVENTS = {
  intro: {
    async run(g) {
      await g.say('', "Las Casernas, 7 h du matin.\nTu gares ton van sous les pins. La planche est sur le toit.");
      await g.say('', "Dans ta poche : 42 €. Dans ton cœur : 5 points de Stoke.\nTa Légende : 0. Pour l'instant.");
      await g.say('', "Il paraît que ce matin, ça rentre bien. La Plage est en haut du Parking.\n…Mais quelqu'un a l'air de galérer, là-bas.");
    },
  },

  morningControl: {
    chance: 0.55,
    async run(g) {
      const s = g.s;
      const sp = g.map.sleepSpot;
      g.spawnTemp({ id: 'garde', name: 'Agent municipal', look: 'garde', x: sp.x, y: sp.y + 1, facing: 'up' });
      await g.say('', '* toc toc toc *');
      const c = await g.ask('Agent municipal', 'Bonjour. Vous dormez ici ?', [
        { label: 'Non, je médite très profondément.' },
        { label: "J'attends la marée, chef." },
        { label: 'Je suis le cousin de Jo, du camping.' },
      ]);
      const chance = 0.5 + Math.min(0.25, s.legend * 0.03);
      const ok = Math.random() < chance;
      g.time(20);
      if (ok) {
        await g.say('Agent municipal', [
          "…Ah. La méditation. Ma femme en fait aussi. Bon. Circulez, et namasté.",
          "La marée… Mon père surfait. Allez, circulez. Et bonne session.",
          "Le cousin de Jo ? Tout le monde est le cousin de Jo. …Bon, ça passe pour cette fois.",
        ][c]);
        g.gain({ legend: 1 });
      } else {
        await g.say('Agent municipal', "Le stationnement nocturne est interdit. Je vous laisse un avertissement… et un regard très déçu.");
        g.gain({ stoke: -2 });
      }
      g.removeTemp('garde');
    },
  },

  firstBeach: {
    async run(g) {
      await g.say('', "La Plage. Le drapeau du poste MNS change de couleur selon les conditions : vert, ça vaut le coup.\nApproche-toi de l'eau et INTERAGIS pour surfer.");
    },
  },
};
