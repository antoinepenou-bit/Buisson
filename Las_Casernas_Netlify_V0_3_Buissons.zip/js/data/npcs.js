// PNJ. Chaque PNJ : position, apparence (look), éventuel emote, et un script de dialogue async.
// Le script reçoit `g`, l'API du jeu (voir engine/game.js : say, ask, time, gain, pay, setQuest…).
// Pour ajouter un PNJ : ajouter une entrée ici, rien d'autre à toucher.
import { conditionsAt, nextTopWindow } from './surf.js';
import { fmtTime } from '../state.js';

const pick = arr => arr[Math.floor(Math.random() * arr.length)];

/** PNJ de figuration : une réplique au hasard, discussion courte (+10 min). */
function chatter(name, lines) {
  return async g => { await g.say(name, pick(lines)); g.time(10); };
}

export const SCENE_OPEN_FROM = 18 * 60;
export function sceneIsOpen(t) { return t >= SCENE_OPEN_FROM || t < 60; }
/** La soirée « appartient » au jour où elle a commencé (00:30 compte pour la veille). */
export const eveningOf = s => (s.time < 60 ? s.day - 1 : s.day);

export const NPCS = {
  // ---------------- PARKING ----------------
  nico: {
    name: 'Nico', map: 'parking', x: 11, y: 5, facing: 'up',
    look: { skin: '#d9a074', hair: '#2a1d14', style: 'short', shirt: '#4f8a5b', pants: '#3b4a6b', beard: true, cap: '#c4472f' },
    emote: s => (!s.quests.battery || s.quests.battery === 'refused' || s.quests.battery === 'cables') ? '!' : null,
    async talk(g) {
      const q = g.s.quests.battery;
      if (!q || q === 'refused') {
        await g.say('Nico', q === 'refused'
          ? "Ah, te revoilà. Toujours le capot ouvert, toujours le moral fermé.\nT'aurais pas des câbles, finalement ?"
          : 'Mec… t’aurais pas des câbles ? Les gars du Camping doivent en avoir. Si tu pars maintenant, tu risques de rater la meilleure marée.');
        const c = await g.ask('Nico', 'Alors, tu me dépannes ?', [
          { label: "OK, j'y vais", sub: 'Quête : Batterie à plat' },
          { label: "Plus tard, la marée m'appelle", sub: 'Refuser pour le moment' },
        ]);
        g.time(10);
        if (c === 0) {
          g.setQuest('battery', 'active');
          g.rel('nico', 1);
          await g.say('Nico', "T'es un frère. Demande à Jo, à l'accueil du Camping. C'est à droite du parking, tu peux pas le rater. Enfin si, mais essaie.");
        } else {
          g.setQuest('battery', 'refused');
          await g.say('Nico', "Je comprends. La vague, c'est sacré. Moi je reste là, avec mon capot et mes regrets.");
        }
      } else if (q === 'active') {
        await g.say('Nico', "Le Camping, c'est par la droite. Jo a toujours tout. Sauf de la monnaie.");
        g.time(5);
      } else if (q === 'cables') {
        await g.say('Nico', "LES CÂBLES ! Rouge sur le plus, noir sur la masse. Ou l'inverse. On va voir.");
        await g.fade('* VRRR… VRRR… VROUUUM *', 1300);
        g.time(20);
        g.setQuest('battery', 'done');
        g.rel('nico', 2);
        g.gain({ legend: 1, stoke: 1 });
        await g.say('Nico', 'Elle démarre ! Elle DÉMARRE ! Je te dois un service.');
      } else {
        await g.say('Nico', 'Je te dois un service.');
        g.time(10);
      }
    },
  },
  kevin: {
    name: 'Kévin', map: 'parking', x: 8, y: 16, facing: 'down',
    look: { skin: '#f0c49b', hair: '#d9b45a', style: 'manbun', shirt: '#d8c7a2', pants: '#6b7f4a', beard: true },
    talk: chatter('Kévin', [
      "Je fais la salutation au soleil. Il est pas encore très réveillé, lui. Moi non plus.",
      "J'ai vendu mon appart à Lyon pour vivre dans un Kangoo. Meilleure décision. Pire dos.",
      "Si tu dors sur le parking, gare-toi loin du panneau. Ils passent tôt, les gars de la mairie.",
      "Le Stoke, c'est une énergie. Comme le wifi, mais en moins fiable.",
    ]),
  },

  // ---------------- CAMPING ----------------
  jo: {
    name: 'Jo', map: 'camping', x: 3, y: 5, facing: 'down',
    look: { skin: '#c98d5e', hair: '#9a9590', style: 'bun', shirt: '#f2c230', pants: '#2f6b4f', glasses: true },
    emote: s => s.quests.battery === 'active' ? '?' : null,
    async talk(g) {
      const q = g.s.quests.battery;
      if (q === 'active') {
        await g.say('Jo', "Des câbles ? Ici on a des câbles, des sardines, des pinces à linge et un vieux matelas gonflable qui s'appelle Gérard.");
        await g.say('Jo', "Tiens. Tu me les ramènes, hein. C'est les câbles de mon beau-frère, il est sensible.");
        g.time(15);
        g.setQuest('battery', 'cables');
        g.rel('jo', 1);
        g.toast('Câbles de démarrage obtenus', 'good');
        return;
      }
      if (q === 'cables') {
        await g.say('Jo', "Les câbles, c'est pour Nico. Pas pour faire de la corde à sauter. File !");
        g.time(5);
        return;
      }
      const c = await g.ask('Jo', "Bienvenue aux Pignadas ! Douche 3 €, nuit 12 €, bonne humeur gratuite (dans la limite des stocks).", [
        { label: 'Réserver une nuit', sub: '12 € · +2 Stoke · réveil 07:00' },
        { label: 'Papoter', sub: '+10 min' },
        { label: 'Rien, merci' },
      ]);
      if (c === 0) return g.action('accueil');
      if (c === 1) {
        g.time(10);
        if (!g.s.daily.joChat) { g.s.daily.joChat = true; g.rel('jo', 1); }
        await g.say('Jo', pick([
          "Le camping, c'est comme la mer : y a des marées. Le matin les gens partent surfer, le soir ils reviennent avec du sable partout.",
          "Le parking, c'est gratuit, mais les gars de la mairie passent au lever du jour. Moi je dis ça…",
          "Gérard, le matelas, il a fait 14 saisons. Respect.",
        ]));
      }
    },
  },
  gege: {
    name: 'Gégé', map: 'camping', x: 12, y: 11, facing: 'left',
    look: { skin: '#f2b493', hair: '#6b5a4a', style: 'bald', shirt: '#f4f1ea', pants: '#2b77a8', moustache: true },
    emote: s => s.daily.gegeJob ? null : '€',
    async talk(g) {
      if (g.s.daily.gegeJob) {
        await g.say('Gégé', "Mon auvent tient debout. Grâce à toi. Et un peu grâce à la colle.");
        g.time(5);
        return;
      }
      const c = await g.ask('Gégé', "Dis, tu peux m'aider à monter mon auvent ? Ma femme dit que je suis pas manuel. Je te file 8 €.", [
        { label: 'Allez, on monte ça', sub: '+8 € · 30 min' },
        { label: 'Pas le temps' },
      ]);
      if (c === 0) {
        g.time(30);
        g.s.daily.gegeJob = true;
        g.gain({ money: 8 });
        await g.say('Gégé', "Ahhh, magnifique. On dirait un vrai. Tiens, tes 8 €. Ne dis rien à ma femme.");
      } else {
        g.time(5);
        await g.say('Gégé', "Bon. Je vais lire la notice. Encore.");
      }
    },
  },
  josiane: {
    name: 'Josiane', map: 'camping', x: 3, y: 13, facing: 'right',
    look: { skin: '#f0c49b', hair: '#e1d3b0', style: 'curly', shirt: '#e88aa0', pants: '#f4f1ea', hat: '#f3d36b' },
    talk: chatter('Josiane', [
      "Tu tires ou tu pointes ? Non parce que là, tu traînes.",
      "Je viens ici depuis 1987. Le camping a changé trois fois de nom, moi jamais.",
      "Mon mari surfe. Enfin, il porte une combinaison et il regarde la mer. C'est pareil ?",
    ]),
  },

  // ---------------- PLAGE ----------------
  ancien: {
    name: "L'Ancien", map: 'plage', x: 5, y: 8, facing: 'up',
    look: { skin: '#b97a50', hair: '#f4f1ea', style: 'long', shirt: '#c4472f', pants: '#e9d8a6', beard: true, beardColor: '#f4f1ea', hat: '#e7c98d' },
    async talk(g) {
      await g.say("L'Ancien", 'Avant 10 h, ça vaut le coup. Ce soir aussi si le vent tombe.');
      const c = await g.ask("L'Ancien", '…Tu veux savoir autre chose, petit ?', [
        { label: 'Et là, maintenant ?' },
        { label: 'Un conseil de vieux ?' },
        { label: "Merci, l'Ancien" },
      ]);
      g.time(10);
      if (!g.s.daily.ancienChat) { g.s.daily.ancienChat = true; g.rel('ancien', 1); }
      if (c === 0) {
        const cond = conditionsAt(g.s.time);
        const next = nextTopWindow(g.s.time);
        const nextTxt = next.tomorrow ? `Demain matin dès ${fmtTime(next.from)}.` :
          (g.s.time >= next.from ? `Et c'est maintenant, jusqu'à ${fmtTime(next.to)}. Qu'est-ce que tu fais encore là ?` : `Le prochain bon créneau : ${fmtTime(next.from)}–${fmtTime(next.to)}.`);
        await g.say("L'Ancien", `Là ? ${cond.label}. ${cond.note}\n${nextTxt}`);
      } else if (c === 1) {
        await g.say("L'Ancien", pick([
          "En 83, j'ai pris une vague si longue que je suis arrivé à Hossegor. Je suis rentré à pied.",
          "La planche, c'est comme un chien. Si tu la cires pas, elle te mord.",
          "Le Stoke, ça se garde. Une douche chaude, un verre avec les copains… Plus t'en as, plus le take-off est facile.",
          "Les vagues reviennent toujours. Les créneaux, eux, non.",
        ]));
      }
    },
  },
  maite: {
    name: 'Maïté', map: 'plage', x: 2, y: 11, facing: 'right',
    look: { skin: '#c98d5e', hair: '#1f1a17', style: 'ponytail', shirt: '#1f2a33', pants: '#1f2a33', wetsuit: '#3d8fbf' },
    talk: chatter('Maïté', [
      "Le banc a bougé cette nuit. À gauche du poste MNS, ça ferme moins.",
      "Regarde le drapeau du poste : vert, fonce. Jaune, ça se tente. Orange… va boire un café.",
      "J'ai raté la session de ce matin pour aider un mec avec sa tente. Il m'a offert une chips. UNE.",
    ]),
  },
  patrick: {
    name: 'Patrick', map: 'plage', x: 8, y: 13, facing: 'down',
    look: { skin: '#a8643a', hair: '#2a1d14', style: 'short', shirt: '#a8643a', pants: '#e8743b', sunglasses: true, pose: 'lying' },
    talk: chatter('Patrick', [
      "Chuuut. Je dore.",
      "Je suis là depuis juin. Je crois. On est quel jour ?",
      "Surfer ? Non. Moi je fais du bronzage de compétition. Catégorie vétéran.",
    ]),
  },

  // ---------------- BAR ----------------
  lina: {
    name: 'Lina', map: 'bar', x: 11, y: 14, facing: 'down',
    look: { skin: '#e0a77c', hair: '#8a2f1f', style: 'long', shirt: '#2a2a2a', pants: '#3b4a6b', earrings: true },
    emote: s => (sceneIsOpen(s.time) && s.flags.gigDay !== eveningOf(s)) ? '♪' : null,
    async talk(g) {
      const s = g.s;
      const open = sceneIsOpen(s.time);
      const played = s.flags.gigDay === eveningOf(s);
      let intro = 'La scène ouverte commence bientôt. Tu joues ?';
      if (open && !played) intro = "La scène ouverte a commencé ! Il nous manque quelqu'un avec du courage. Tu joues ?";
      if (!open) intro += `\n(Elle ouvre à ${fmtTime(SCENE_OPEN_FROM)}.)`;
      if (played) intro = "T'as déjà fait ton show ce soir. Les gens en parlent encore. Enfin, deux personnes.";
      const choices = [
        { label: 'Offrir un verre', sub: '5 € · +2 Stoke · 30 min', id: 'drink' },
        { label: 'Jouer à la scène ouverte', sub: open && !played ? 'Mini-jeu · 45 min' : (played ? 'Déjà joué ce soir' : 'Pas encore ouverte'), id: 'gig', disabled: !open || played },
        { label: 'Discuter', sub: '+10 min', id: 'chat' },
      ];
      if (!open && s.time >= 7 * 60) choices.push({ label: "Attendre l'ouverture", sub: `jusqu'à ${fmtTime(SCENE_OPEN_FROM)}`, id: 'wait' });
      choices.push({ label: 'À plus', id: 'bye' });
      const c = choices[await g.ask('Lina', intro, choices)].id;
      if (c === 'drink') {
        if (!g.pay(5)) return g.say('Lina', "Pas de sous ? T'inquiète, je note sur l'ardoise des rêves.");
        g.time(30);
        g.gain({ stoke: 2 });
        g.rel('lina', 1);
        await g.say('Lina', pick([
          "Santé ! Au prochain take-off.",
          "Merci ! Tu sais que t'es le premier à m'offrir un verre sans me parler de ta planche ? …Ah si, tu m'en parles.",
          "À la tienne. Et au vent qui tombe.",
        ]));
      } else if (c === 'gig') {
        await g.gig();
      } else if (c === 'chat') {
        g.time(10);
        await g.say('Lina', pick([
          "Ici, le soir, les surfeurs deviennent musiciens. Et les musiciens deviennent… pires.",
          "Si tu joues ce soir, fais simple : trois accords et la vérité.",
          "Nico ? Son van tombe en panne une fois par semaine. C'est sa façon de se faire des amis.",
        ]));
      } else if (c === 'wait') {
        g.time(SCENE_OPEN_FROM - s.time);
        await g.say('Lina', "Et voilà, c'est l'heure ! Les amplis chauffent, les cœurs aussi.");
      }
    },
  },
  fred: {
    name: 'Fred', map: 'bar', x: 3, y: 11, facing: 'down',
    look: { skin: '#e8b48a', hair: '#5a3a22', style: 'short', shirt: '#f4f1ea', pants: '#2a1d14', moustache: true, apron: true },
    talk: async g => g.action('counter'),
  },
  bixente: {
    name: 'Bixente', map: 'bar', x: 2, y: 16, facing: 'right',
    look: { skin: '#e8b48a', hair: '#2a1d14', style: 'short', shirt: '#f4f1ea', pants: '#2a1d14', beret: '#1f2a33', scarf: '#c4472f' },
    talk: chatter('Bixente', [
      "Ici on parle de vagues, de rugby, et de vagues de rugby.",
      "Mon grand-père surfait sur une porte de grange. Toi t'as une planche en mousse ? Il aurait pleuré.",
      "Le soir, quand le vent tombe, la mer devient de l'huile. Faut pas rater ça.",
    ]),
  },
  paulette: {
    name: 'Paulette', map: 'bar', x: 11, y: 7, facing: 'right',
    look: { skin: '#f0c49b', hair: '#d8d4cf', style: 'curly', shirt: '#7a5a9a', pants: '#3b4a6b', glasses: true },
    talk: chatter('Paulette', [
      "J'ai vu passer le contrôle ce matin. Ils ont mis un avertissement à une tente. Elle s'est envolée avant de signer.",
      "Le Swell, avant, c'était une conserverie de sardines. Ça se sent encore les jours de pluie.",
      "Un jeune homme bien comme vous, ça dort au camping. Ou chez Paulette. Je plaisante. Quoique.",
    ]),
  },
};

/** Apparences hors PNJ (joueur, personnages d'événements). */
export const LOOKS = {
  player: { skin: '#e8b48a', hair: '#6b3e1f', style: 'short', shirt: '#2b77a8', pants: '#e8743b', headband: '#f3d36b' },
  garde: { skin: '#e8b48a', hair: '#3a2a1e', style: 'short', shirt: '#2c4a7a', pants: '#1f2a44', cap: '#1f2a44', moustache: true },
};
