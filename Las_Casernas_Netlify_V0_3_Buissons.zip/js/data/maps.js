// Cartes du monde. Chaque carte = une grille de terrain + des props (décor/objets) + des sorties.
// Pour ajouter une carte (Village, Buissons, Chemin…) : écrire une fonction build*, l'ajouter à MAPS,
// déclarer ses sorties et ses temps de trajet dans TRAVEL.
//
// Terrain :  a asphalte · n aiguilles de pin · g herbe · s sable · d dune · p chemin de sable
//            w océan (bloquant) · r terrasse · b plancher · D seuil de porte · x fourré dense (rencontre)
//            T pin (bloquant) · F ganivelle (bloquant) · W mur (bloquant)

export const TILE = 16;
export const SOLID_TERRAIN = new Set(['w', 'T', 'F', 'W']);

/** Temps de trajet entre deux zones (minutes). Symétrique. */
export const TRAVEL = {
  'parking|camping': 15,
  'parking|plage': 25,
  'parking|bar': 30,
  'camping|plage': 25,
  'plage|bar': 25,
  'camping|bar': 20,
  'parking|buissons': 8,
  'buissons|camping': 10,
  'buissons|plage': 10,
};
export function travelTime(a, b) {
  return TRAVEL[`${a}|${b}`] ?? TRAVEL[`${b}|${a}`] ?? 20;
}

function grid(w, h, t) { return Array.from({ length: h }, () => Array(w).fill(t)); }
function fill(g, x, y, w, h, t) {
  for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) if (g[j] && g[j][i] !== undefined) g[j][i] = t;
}
function border(g, t) {
  const h = g.length, w = g[0].length;
  fill(g, 0, 0, w, 1, t); fill(g, 0, h - 1, w, 1, t);
  fill(g, 0, 0, 1, h, t); fill(g, w - 1, 0, 1, h, t);
}
function dots(g, list, t) { for (const [x, y] of list) g[y][x] = t; }

const W = 16, H = 22;

function buildParking() {
  const g = grid(W, H, 'n');
  fill(g, 2, 2, 12, 18, 'a');
  border(g, 'T');
  // Sorties : haut → Plage, droite → Camping, bas → Bar
  fill(g, 7, 0, 2, 2, 'p');
  fill(g, 14, 10, 2, 2, 'p');
  fill(g, 7, 20, 2, 2, 'p');
  fill(g, 0, 6, 2, 2, 'p'); // raccourci Buissons
  dots(g, [[1, 2], [1, 8], [1, 16], [1, 19], [14, 2], [14, 18], [2, 19], [13, 19]], 'T');
  return {
    id: 'parking', name: 'Parking des Casernas', outdoor: true, w: W, h: H, tiles: g,
    exits: [
      { x: 7, y: 0, w: 2, h: 1, to: 'plage', dir: 'up' },
      { x: 15, y: 10, w: 1, h: 2, to: 'camping', dir: 'right' },
      { x: 7, y: 21, w: 2, h: 1, to: 'bar', dir: 'down' },
      { x: 0, y: 6, w: 1, h: 2, to: 'buissons', dir: 'left' },
    ],
    props: [
      { type: 'van', x: 2, y: 3, w: 3, h: 2, color: 'orange', board: true, interact: 'myvan', label: 'Ton van' },
      { type: 'boards', x: 5, y: 3, w: 1, h: 2 },
      { type: 'van', x: 10, y: 3, w: 3, h: 2, color: 'green', hood: true, interact: 'npc:nico', label: 'Van de Nico' },
      { type: 'cafe', x: 6, y: 8, w: 3, h: 2, interact: 'cafe', label: 'Café de Momo' },
      { type: 'table', x: 5, y: 12 }, { type: 'chair', x: 4, y: 12, solid: false }, { type: 'chair', x: 6, y: 12, solid: false },
      { type: 'table', x: 10, y: 11 }, { type: 'chair', x: 9, y: 11, solid: false }, { type: 'chair', x: 11, y: 11, solid: false },
      { type: 'car', x: 2, y: 14, w: 3, h: 2, color: 'blue' },
      { type: 'car', x: 11, y: 15, w: 3, h: 2, color: 'red' },
      { type: 'paint', x: 6, y: 14, w: 1, h: 2, solid: false }, { type: 'paint', x: 10, y: 15, w: 1, h: 2, solid: false },
      { type: 'sign', x: 6, y: 1, text: 'PLAGE', arrow: 'up', interact: 'sign' },
      { type: 'sign', x: 13, y: 9, text: 'CAMPING', arrow: 'right', interact: 'sign' },
      { type: 'sign', x: 9, y: 20, text: 'BAR', arrow: 'down', interact: 'sign' },
      { type: 'sign', x: 1, y: 5, text: 'BUISSONS', arrow: 'left', interact: 'sign' },
    ],
    sleepSpot: { x: 3, y: 5, facing: 'down' },
  };
}

function buildCamping() {
  const g = grid(W, H, 'g');
  border(g, 'T');
  // Chemins : vertical (Plage ↔ Bar) et horizontal (Parking)
  fill(g, 7, 0, 2, H, 'p');
  fill(g, 0, 10, 8, 2, 'p');
  fill(g, 3, 12, 3, 2, 'p'); // terrain de pétanque
  fill(g, 14, 10, 2, 2, 'p'); // vers Buissons
  dots(g, [[1, 7], [5, 8], [14, 5], [1, 19], [14, 18], [5, 3], [14, 12]], 'T');
  return {
    id: 'camping', name: 'Camping Les Pignadas', outdoor: true, w: W, h: H, tiles: g,
    exits: [
      { x: 0, y: 10, w: 1, h: 2, to: 'parking', dir: 'left' },
      { x: 7, y: 0, w: 2, h: 1, to: 'plage', dir: 'up' },
      { x: 7, y: 21, w: 2, h: 1, to: 'bar', dir: 'down' },
      { x: 15, y: 10, w: 1, h: 2, to: 'buissons', dir: 'right' },
    ],
    props: [
      { type: 'building', style: 'accueil', x: 1, y: 2, w: 4, h: 3, interact: 'accueil', label: 'Accueil — dormir' },
      { type: 'building', style: 'sanitaires', x: 10, y: 2, w: 4, h: 3, interact: 'shower', label: 'Sanitaires — douche' },
      { type: 'tent', x: 10, y: 8, w: 2, h: 2, color: 'orange' },
      { type: 'tent', x: 13, y: 8, w: 2, h: 2, color: 'blue' },
      { type: 'tent', x: 10, y: 14, w: 2, h: 2, color: 'green' },
      { type: 'tent', x: 13, y: 14, w: 2, h: 2, color: 'red' },
      { type: 'tent', x: 2, y: 15, w: 2, h: 2, color: 'yellow' },
      { type: 'boules', x: 4, y: 12, solid: false },
      { type: 'parasol', x: 11, y: 11 },
      { type: 'clothesline', x: 10, y: 18, w: 3, h: 1 },
      { type: 'table', x: 4, y: 18 }, { type: 'chair', x: 3, y: 18, solid: false }, { type: 'chair', x: 5, y: 18, solid: false },
      { type: 'sign', x: 9, y: 1, text: 'PLAGE', arrow: 'up', interact: 'sign' },
      { type: 'sign', x: 1, y: 12, text: 'PARKING', arrow: 'left', interact: 'sign' },
      { type: 'sign', x: 9, y: 20, text: 'BAR', arrow: 'down', interact: 'sign' },
      { type: 'sign', x: 13, y: 9, text: 'BUISSONS', arrow: 'right', interact: 'sign' },
    ],
    sleepSpot: { x: 2, y: 5, facing: 'down' },
  };
}

function buildPlage() {
  const g = grid(W, H, 's');
  fill(g, 0, 0, W, 7, 'w');
  fill(g, 1, 16, 14, 4, 'd');
  fill(g, 0, 20, W, 1, 'n');
  fill(g, 0, 21, W, 1, 'T');
  fill(g, 0, 7, 1, 14, 'F');
  fill(g, W - 1, 7, 1, 14, 'F');
  // Sorties : bas → Parking, droite → Camping, gauche → Bar
  fill(g, 7, 17, 2, 5, 'p');
  fill(g, 2, 20, 2, 2, 'p'); // vers Buissons
  fill(g, 0, 15, 1, 2, 's');
  fill(g, W - 1, 15, 1, 2, 's');
  // Ganivelles dans les dunes
  fill(g, 1, 18, 5, 1, 'F');
  fill(g, 10, 18, 5, 1, 'F');
  return {
    id: 'plage', name: 'Plage de la Centrale', outdoor: true, w: W, h: H, tiles: g, beach: true,
    exits: [
      { x: 7, y: 21, w: 2, h: 1, to: 'parking', dir: 'down' },
      { x: 15, y: 15, w: 1, h: 2, to: 'camping', dir: 'right' },
      { x: 0, y: 15, w: 1, h: 2, to: 'bar', dir: 'left' },
      { x: 2, y: 21, w: 2, h: 1, to: 'buissons', dir: 'down' },
    ],
    props: [
      { type: 'mns', x: 11, y: 8, w: 2, h: 3 },
      { type: 'board', x: 13, y: 10, interact: 'board', label: 'Tableau MNS' },
      { type: 'surfer', x: 3, y: 3, solid: false }, { type: 'surfer', x: 9, y: 2, solid: false, phase: 2 },
      { type: 'surfer', x: 12, y: 4, solid: false, phase: 4 },
      { type: 'sandboard', x: 3, y: 9 },
      { type: 'towel', x: 8, y: 13, solid: false },
      { type: 'parasol', x: 9, y: 12 },
      { type: 'oyat', x: 2, y: 16, solid: false }, { type: 'oyat', x: 5, y: 17, solid: false },
      { type: 'oyat', x: 11, y: 16, solid: false }, { type: 'oyat', x: 13, y: 17, solid: false },
      { type: 'oyat', x: 9, y: 19, solid: false }, { type: 'oyat', x: 3, y: 19, solid: false },
      { type: 'sign', x: 9, y: 20, text: 'PARKING', arrow: 'down', interact: 'sign' },
      { type: 'sign', x: 14, y: 14, text: 'CAMPING', arrow: 'right', interact: 'sign' },
      { type: 'sign', x: 1, y: 14, text: 'BAR', arrow: 'left', interact: 'sign' },
      { type: 'sign', x: 2, y: 19, text: 'BUISSONS', arrow: 'down', interact: 'sign' },
    ],
  };
}

function buildBushes() {
  const g = grid(W, H, 'g');
  border(g, 'T');
  // Un labyrinthe lisible : chemins clairs entourés de fourrés denses « x ».
  fill(g, 1, 1, 14, 20, 'x');
  fill(g, 1, 6, 14, 2, 'p');
  fill(g, 7, 0, 2, 22, 'p');
  fill(g, 2, 12, 12, 2, 'p');
  fill(g, 3, 16, 7, 2, 'p');
  fill(g, 0, 6, 2, 2, 'p');
  fill(g, 14, 6, 2, 2, 'p');
  fill(g, 7, 0, 2, 2, 'p');
  fill(g, 7, 20, 2, 2, 'p');
  // clairières pour respirer entre deux rencontres
  fill(g, 3, 3, 3, 2, 'g');
  fill(g, 10, 16, 3, 2, 'g');
  return {
    id: 'buissons', name: 'Les Buissons', outdoor: true, w: W, h: H, tiles: g, bushZone: true,
    exits: [
      { x: 15, y: 6, w: 1, h: 2, to: 'parking', dir: 'right' },
      { x: 7, y: 0, w: 2, h: 1, to: 'camping', dir: 'up' },
      { x: 7, y: 21, w: 2, h: 1, to: 'plage', dir: 'down' },
    ],
    props: [
      { type: 'sign', x: 13, y: 5, text: 'PARKING', arrow: 'right', interact: 'sign' },
      { type: 'sign', x: 9, y: 1, text: 'CAMPING', arrow: 'up', interact: 'sign' },
      { type: 'sign', x: 9, y: 20, text: 'PLAGE', arrow: 'down', interact: 'sign' },
      { type: 'parasol', x: 4, y: 4, solid: false },
      { type: 'chair', x: 11, y: 17, solid: false },
    ],
  };
}

function buildBar() {
  const g = grid(W, H, 'r');
  // Terrasse (haut) + salle (bas)
  fill(g, 0, 0, W, 1, 'T');
  fill(g, 0, 0, 1, 9, 'T');
  fill(g, W - 1, 0, 1, 9, 'T');
  fill(g, 7, 0, 2, 1, 'p');
  fill(g, 0, 4, 1, 2, 'p');
  fill(g, W - 1, 4, 1, 2, 'p');
  fill(g, 0, 9, W, 1, 'W');
  fill(g, 7, 9, 2, 1, 'D');
  fill(g, 1, 10, 14, 11, 'b');
  fill(g, 0, 9, 1, 13, 'W');
  fill(g, W - 1, 9, 1, 13, 'W');
  fill(g, 0, 21, W, 1, 'W');
  return {
    id: 'bar', name: 'Bar Le Swell', outdoor: true, w: W, h: H, tiles: g,
    exits: [
      { x: 7, y: 0, w: 2, h: 1, to: 'parking', dir: 'up' },
      { x: 15, y: 4, w: 1, h: 2, to: 'camping', dir: 'right' },
      { x: 0, y: 4, w: 1, h: 2, to: 'plage', dir: 'left' },
    ],
    props: [
      { type: 'barsign', x: 2, y: 9, w: 4, h: 1, solid: false },
      { type: 'terrace_table', x: 3, y: 2 }, { type: 'terrace_table', x: 12, y: 2 },
      { type: 'terrace_table', x: 3, y: 7 }, { type: 'terrace_table', x: 12, y: 7 },
      { type: 'chair', x: 2, y: 2, solid: false }, { type: 'chair', x: 13, y: 2, solid: false },
      { type: 'chair', x: 4, y: 7, solid: false }, { type: 'chair', x: 11, y: 2, solid: false },
      { type: 'shelf', x: 1, y: 10, w: 5, h: 1 },
      { type: 'counter', x: 1, y: 12, w: 5, h: 1, interact: 'counter', label: 'Comptoir — Fred' },
      { type: 'jukebox', x: 14, y: 10 },
      { type: 'stage', x: 9, y: 17, w: 6, h: 3, interact: 'stage', label: 'Scène ouverte' },
      { type: 'table', x: 3, y: 16 }, { type: 'chair', x: 4, y: 16, solid: false },
      { type: 'table', x: 6, y: 18 }, { type: 'chair', x: 5, y: 18, solid: false },
      { type: 'sign', x: 9, y: 1, text: 'PARKING', arrow: 'up', interact: 'sign' },
    ],
  };
}

export const MAPS = {
  parking: buildParking(),
  camping: buildCamping(),
  plage: buildPlage(),
  bar: buildBar(),
  buissons: buildBushes(),
};
