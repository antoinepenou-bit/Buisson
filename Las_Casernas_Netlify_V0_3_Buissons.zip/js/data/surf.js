// Fenêtres de surf. Pour ajouter des spots ou des marées : ajouter un tableau par spot
// et/ou rendre `windows` dépendant du jour (météo, coefficient…).
export const SURF_REWARDS = {
  top: { legend: 4, stoke: 1 },
  ok: { legend: 2, stoke: 1 },
  avg: { legend: 1, stoke: 1 },
  fail: { stoke: -1 },
};

export const SURF_SESSION_MIN = 75;

export const SPOTS = {
  casernas: {
    name: 'La Centrale de Las Casernas',
    windows: [
      { from: 7 * 60, to: 9 * 60 + 30, quality: 'top', label: 'Très bonnes', note: 'Offshore léger, ça déroule.' },
      { from: 9 * 60 + 30, to: 11 * 60 + 30, quality: 'ok', label: 'Correctes', note: 'Ça commence à se lever un peu.' },
      { from: 17 * 60, to: 19 * 60 + 30, quality: 'top', label: 'Très bonnes (soir)', note: 'Le vent tombe, glassy.' },
    ],
    night: { from: 22 * 60, to: 6 * 60 },
  },
};

const QUALITY_INFO = {
  top: { label: 'Très bonnes', color: 'top', zone: 1.0 },
  ok: { label: 'Correctes', color: 'ok', zone: 1.0 },
  avg: { label: 'Moyennes', color: 'avg', zone: 1.0 },
  night: { label: 'Nuit noire', color: 'night', zone: 0 },
};

export function conditionsAt(time, spotId = 'casernas') {
  const spot = SPOTS[spotId];
  const t = time % 1440;
  const n = spot.night;
  if (t >= n.from || t < n.to) return { quality: 'night', label: 'Nuit noire', note: 'On ne voit même pas ses pieds.', ...QUALITY_INFO.night };
  const w = spot.windows.find(w => t >= w.from && t < w.to);
  if (w) return { ...QUALITY_INFO[w.quality], ...w };
  return { quality: 'avg', ...QUALITY_INFO.avg, note: 'Clapoteux, un peu de vent.' };
}

/** Prochaine « très bonne » fenêtre à partir de maintenant (pour les conseils). */
export function nextTopWindow(time, spotId = 'casernas') {
  const t = time % 1440;
  const tops = SPOTS[spotId].windows.filter(w => w.quality === 'top');
  return tops.find(w => w.to > t) || { ...tops[0], tomorrow: true };
}
