// Quêtes. Le statut de chaque quête vit dans state.quests[id].
// Les étapes sont pilotées par les dialogues des PNJ (voir npcs.js) via g.setQuest().
// Pour une chaîne de quêtes : ajouter `next: 'autreQuete'` et la démarrer à la complétion.
export const QUESTS = {
  battery: {
    title: 'Batterie à plat',
    giver: 'nico',
    objectives: {
      refused: 'Nico galère encore avec son van (Parking)',
      active: 'Trouver des câbles au Camping (demander à Jo)',
      cables: 'Rapporter les câbles à Nico (Parking)',
      done: 'Nico est reparti. Il te doit un service.',
    },
    reward: { legend: 1, stoke: 1 },
  },
};

/** Texte d'objectif de la quête en cours la plus pertinente (pour le HUD). */
export function currentObjective(s) {
  for (const [id, q] of Object.entries(QUESTS)) {
    const st = s.quests[id];
    if (st === 'active' || st === 'cables') return `${q.title} : ${q.objectives[st]}`;
  }
  return null;
}
